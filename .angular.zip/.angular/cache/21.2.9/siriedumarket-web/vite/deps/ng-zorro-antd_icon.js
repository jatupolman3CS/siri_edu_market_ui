import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-UAVOBCB5.js";
import "./chunk-BQ76GOFF.js";
import "./chunk-3ETM53XW.js";
import "./chunk-EOPJXEBI.js";
import "./chunk-2FCBR325.js";
import "./chunk-VX4VTDP4.js";
import "./chunk-PSYVM4A7.js";
import "./chunk-TB574D6W.js";
import "./chunk-URLQFT4W.js";
import "./chunk-ZPYQWALE.js";
import "./chunk-KY4W5S5G.js";
import "./chunk-JROCCIV3.js";
import "./chunk-GOMI4DH3.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
