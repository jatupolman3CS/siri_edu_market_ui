import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-logo',
  standalone: true,
  imports: [RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <a [routerLink]="link()" class="inline-flex items-center gap-2.5 group">
      <span
        class="relative flex items-center justify-center w-10 h-10 rounded-2xl bg-gradient-to-br from-pink-300 to-pink-500 shadow-soft transition-transform group-hover:rotate-[-6deg]"
      >
        <svg viewBox="0 0 24 24" fill="none" class="w-6 h-6 text-white">
          <path
            d="M6 4.5C6 3.67 6.67 3 7.5 3h7.18a2 2 0 0 1 1.42.59l3.31 3.32a2 2 0 0 1 .59 1.41V19.5c0 .83-.67 1.5-1.5 1.5h-11A1.5 1.5 0 0 1 6 19.5v-15Z"
            stroke="currentColor"
            stroke-width="1.6"
            stroke-linejoin="round"
          />
          <path
            d="M14 3v4.5a1.5 1.5 0 0 0 1.5 1.5H20"
            stroke="currentColor"
            stroke-width="1.6"
            stroke-linejoin="round"
          />
          <path
            d="M9.5 13h6m-6 3h4"
            stroke="currentColor"
            stroke-width="1.6"
            stroke-linecap="round"
          />
        </svg>
        <span
          class="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-pink-200 border-2 border-white"
        ></span>
      </span>
      @if (showText()) {
        <span class="flex flex-col leading-none">
          <span class="text-[15px] font-extrabold tracking-tight text-ink">
            SIRIEDUMARKET
          </span>
          <span class="text-[10px] uppercase tracking-[0.2em] text-pink-500 mt-1">
            Document Studio
          </span>
        </span>
      }
    </a>
  `,
})
export class LogoComponent {
  readonly link = input<string>('/');
  readonly showText = input<boolean>(true);
}
