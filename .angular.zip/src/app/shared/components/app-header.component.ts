import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
} from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import {
  CartService,
  AuthService,
  WishlistService,
} from '../../core/services';
import { NzMessageService } from 'ng-zorro-antd/message';
import { LogoComponent } from './logo.component';
import { IconComponent } from './icon.component';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [
    RouterLink,
    RouterLinkActive,
    FormsModule,
    NzDropDownModule,
    LogoComponent,
    IconComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header
      class="sticky top-0 z-30 backdrop-blur-md bg-white/85 border-b border-line"
    >
      <div class="max-w-7xl mx-auto px-4 lg:px-6">
        <div class="flex items-center gap-4 h-[68px]">
          <!-- Logo -->
          <app-logo />

          <!-- Nav -->
          <nav class="hidden md:flex items-center gap-1 ml-4">
            @for (item of navItems; track item.href) {
              <a
                [routerLink]="item.href"
                routerLinkActive="!bg-pink-50 !text-pink-600"
                [routerLinkActiveOptions]="{ exact: item.exact ?? false }"
                class="px-3.5 py-2 rounded-full text-sm font-medium text-ink-soft hover:text-pink-600 hover:bg-pink-50 transition-colors"
              >
                {{ item.label }}
              </a>
            }
          </nav>

          <!-- Search -->
          <div class="flex-1 max-w-md ml-auto hidden lg:block">
            <form class="relative" (ngSubmit)="search()">
              <span
                class="absolute left-4 top-1/2 -translate-y-1/2 text-ink-muted"
              >
                <app-icon name="search" [size]="18" />
              </span>
              <input
                type="search"
                [(ngModel)]="query"
                name="q"
                placeholder="ค้นหาเอกสาร เทมเพลต หรือผู้ขาย…"
                class="w-full pl-11 pr-4 py-2.5 rounded-full border border-line bg-pink-50/40 focus:bg-white focus:border-pink-300 focus:outline-none focus:ring-4 focus:ring-pink-100 text-sm transition-all"
              />
            </form>
          </div>

          <!-- Right actions -->
          <div class="flex items-center gap-2 ml-auto lg:ml-0">
            <a routerLink="/marketplace" class="btn-icon lg:hidden">
              <app-icon name="search" [size]="18" />
            </a>

            <!-- Wishlist -->
            <a
              routerLink="/wishlist"
              class="relative btn-icon"
              title="รายการโปรด"
            >
              <app-icon name="heart" [size]="18" />
              @if (wishlist.count() > 0) {
                <span
                  class="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-pink-500 text-white text-[10px] font-bold flex items-center justify-center border-2 border-white"
                >
                  {{ wishlist.count() }}
                </span>
              }
            </a>

            <a
              routerLink="/library"
              class="btn-icon"
              title="คลังเอกสารของฉัน"
            >
              <app-icon name="package" [size]="18" />
            </a>

            <!-- Cart -->
            <button
              type="button"
              class="relative btn-icon"
              (click)="cart.toggleDrawer()"
              [attr.aria-label]="'ตะกร้าสินค้า ' + cart.count() + ' รายการ'"
            >
              <app-icon name="cart" [size]="18" />
              @if (cart.count() > 0) {
                <span
                  class="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-pink-500 text-white text-[10px] font-bold flex items-center justify-center border-2 border-white"
                >
                  {{ cart.count() }}
                </span>
              }
            </button>

            <!-- User menu -->
            @if (auth.user(); as u) {
              <button
                nz-dropdown
                [nzDropdownMenu]="userMenu"
                nzPlacement="bottomRight"
                nzTrigger="click"
                class="flex items-center gap-2 ml-1 px-1.5 py-1.5 rounded-full hover:bg-pink-50 transition-colors"
              >
                <img
                  [src]="u.avatar"
                  [alt]="u.name"
                  class="w-8 h-8 rounded-full object-cover ring-2 ring-pink-100"
                />
                <span class="hidden md:inline text-sm font-medium text-ink">
                  {{ firstName(u.name) }}
                </span>
                <span class="hidden md:inline text-ink-muted">
                  <app-icon name="chevron-down" [size]="14" />
                </span>
              </button>

              <nz-dropdown-menu #userMenu="nzDropdownMenu">
                <ul nz-menu class="!rounded-2xl !p-2 !shadow-pop !min-w-[220px]">
                  <li class="px-3 py-2 border-b border-line mb-1">
                    <div class="text-sm font-semibold text-ink">{{ u.name }}</div>
                    <div class="text-xs text-ink-muted">{{ u.email }}</div>
                  </li>
                  <li nz-menu-item (click)="go('/library')" class="!rounded-xl">
                    <span class="flex items-center gap-2 text-ink">
                      <app-icon name="package" [size]="16" />
                      คลังเอกสารของฉัน
                    </span>
                  </li>
                  <li nz-menu-item (click)="go('/orders')" class="!rounded-xl">
                    <span class="flex items-center gap-2 text-ink">
                      <app-icon name="doc" [size]="16" />
                      ประวัติคำสั่งซื้อ
                    </span>
                  </li>
                  <li nz-menu-item (click)="go('/seller')" class="!rounded-xl">
                    <span class="flex items-center gap-2 text-ink">
                      <app-icon name="dashboard" [size]="16" />
                      Siri Studio (ผู้ขาย)
                    </span>
                  </li>
                  <li nz-menu-item (click)="go('/admin')" class="!rounded-xl">
                    <span class="flex items-center gap-2 text-ink">
                      <app-icon name="shield" [size]="16" />
                      Admin Panel
                    </span>
                  </li>
                  <li nz-menu-divider></li>
                  <li nz-menu-item (click)="signOut()" class="!rounded-xl">
                    <span class="flex items-center gap-2 text-rose-500">
                      <app-icon name="logout" [size]="16" />
                      ออกจากระบบ
                    </span>
                  </li>
                </ul>
              </nz-dropdown-menu>
            } @else {
              <a
                routerLink="/auth/login"
                class="hidden sm:inline-flex items-center text-sm font-medium text-ink hover:text-pink-600 px-3 py-2"
              >
                เข้าสู่ระบบ
              </a>
              <a routerLink="/auth/register" class="btn-pink !px-4 !py-2 text-sm">
                สมัครฟรี
              </a>
            }
          </div>
        </div>
      </div>
    </header>
  `,
})
export class AppHeaderComponent {
  readonly cart = inject(CartService);
  readonly auth = inject(AuthService);
  readonly wishlist = inject(WishlistService);
  private readonly router = inject(Router);
  private readonly message = inject(NzMessageService);

  readonly query = signal<string>('');

  readonly navItems = [
    { label: 'หน้าแรก', href: '/', exact: true },
    { label: 'ตลาด', href: '/marketplace' },
    { label: 'หมวดหมู่', href: '/categories' },
    { label: 'แพ็กเกจ', href: '/bundles' },
    { label: 'ฟรี', href: '/free' },
    { label: 'Siri Studio', href: '/seller' },
  ];

  firstName(full: string): string {
    return full.split(' ')[0];
  }

  search(): void {
    if (this.query().trim()) {
      this.router.navigate(['/marketplace'], {
        queryParams: { q: this.query() },
      });
    }
  }

  go(path: string): void {
    this.router.navigate([path]);
  }

  signOut(): void {
    this.auth.signOut();
    this.message.info('ออกจากระบบเรียบร้อย — แล้วเจอกันใหม่ 👋');
    this.router.navigate(['/']);
  }
}
