import { ChangeDetectionStrategy, Component, input } from '@angular/core';

@Component({
  selector: 'app-empty-state',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div
      class="flex flex-col items-center justify-center text-center py-16 px-6"
    >
      <div
        class="w-24 h-24 rounded-3xl bg-gradient-to-br from-pink-100 to-pink-50 flex items-center justify-center text-4xl mb-5"
      >
        {{ emoji() }}
      </div>
      <h3 class="text-lg font-bold text-ink">{{ title() }}</h3>
      @if (description()) {
        <p class="text-sm text-ink-muted mt-1 max-w-sm">{{ description() }}</p>
      }
      <ng-content />
    </div>
  `,
})
export class EmptyStateComponent {
  readonly emoji = input<string>('🌸');
  readonly title = input<string>('ยังไม่มีข้อมูล');
  readonly description = input<string>('');
}
