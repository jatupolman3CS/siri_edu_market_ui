import { ChangeDetectionStrategy, Component, input } from '@angular/core';

@Component({
  selector: 'app-page-hero',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <section
      class="relative overflow-hidden rounded-3xl bg-gradient-pink border border-line p-8 md:p-12 mb-8"
    >
      <!-- decorative blobs -->
      <div
        class="absolute -top-24 -right-16 w-72 h-72 rounded-full opacity-70 glass-blob"
      ></div>
      <div
        class="absolute -bottom-24 -left-16 w-72 h-72 rounded-full opacity-50 glass-blob"
      ></div>
      <div class="relative">
        @if (eyebrow()) {
          <span class="pill-pink mb-4">
            <span class="w-1.5 h-1.5 rounded-full bg-pink-500"></span>
            {{ eyebrow() }}
          </span>
        }
        <h1
          class="text-3xl md:text-4xl font-extrabold tracking-tight text-ink mb-3"
        >
          {{ title() }}
        </h1>
        @if (description()) {
          <p class="text-base text-ink-soft max-w-2xl">{{ description() }}</p>
        }
        <ng-content />
      </div>
    </section>
  `,
})
export class PageHeroComponent {
  readonly eyebrow = input<string>('');
  readonly title = input.required<string>();
  readonly description = input<string>('');
}
