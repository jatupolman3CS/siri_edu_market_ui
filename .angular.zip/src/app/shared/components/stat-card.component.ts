import { ChangeDetectionStrategy, Component, input } from '@angular/core';

@Component({
  selector: 'app-stat-card',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="card-soft p-5 flex flex-col gap-2">
      <div class="flex items-center justify-between text-ink-muted">
        <span class="text-xs font-semibold uppercase tracking-wider">{{ label() }}</span>
        <span class="text-2xl">{{ icon() }}</span>
      </div>
      <div class="text-2xl md:text-3xl font-extrabold text-ink">
        {{ value() }}
      </div>
      @if (trend()) {
        <div class="flex items-center gap-1 text-xs">
          <span
            [class]="
              trend()!.startsWith('-')
                ? 'text-rose-500'
                : 'text-emerald-500'
            "
            class="font-semibold"
          >
            {{ trend() }}
          </span>
          <span class="text-ink-muted">{{ trendLabel() }}</span>
        </div>
      }
    </div>
  `,
})
export class StatCardComponent {
  readonly label = input.required<string>();
  readonly value = input.required<string>();
  readonly icon = input<string>('✨');
  readonly trend = input<string | null>(null);
  readonly trendLabel = input<string>('vs เดือนก่อน');
}
