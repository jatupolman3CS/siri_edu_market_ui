import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { IconComponent } from './icon.component';

@Component({
  selector: 'app-section-header',
  standalone: true,
  imports: [RouterLink, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="flex items-end justify-between gap-4 mb-6">
      <div class="flex flex-col">
        @if (eyebrow()) {
          <span class="text-xs font-semibold text-pink-500 tracking-[0.18em] uppercase mb-2">
            {{ eyebrow() }}
          </span>
        }
        <h2 class="section-title">{{ title() }}</h2>
        @if (subtitle()) {
          <p class="section-subtitle">{{ subtitle() }}</p>
        }
      </div>
      @if (link()) {
        <a
          [routerLink]="link()"
          class="hidden sm:inline-flex items-center gap-1 text-sm font-semibold text-pink-600 hover:text-pink-700 group"
        >
          {{ linkLabel() }}
          <app-icon
            name="arrow-right"
            [size]="16"
            className="transition-transform group-hover:translate-x-0.5"
          />
        </a>
      }
    </header>
  `,
})
export class SectionHeaderComponent {
  readonly eyebrow = input<string>('');
  readonly title = input.required<string>();
  readonly subtitle = input<string>('');
  readonly link = input<string | null>(null);
  readonly linkLabel = input<string>('ดูทั้งหมด');
}
