import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { LogoComponent } from './logo.component';
import { IconComponent } from './icon.component';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [RouterLink, LogoComponent, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <footer class="mt-20 bg-white border-t border-line">
      <div class="max-w-7xl mx-auto px-4 lg:px-6 py-14">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-10">
          <div class="md:col-span-1">
            <app-logo />
            <p class="text-sm text-ink-muted mt-4 leading-relaxed">
              แพลตฟอร์มตลาดกลางสำหรับเอกสารวิชาการ
              สรุปบทเรียน และเทมเพลตคุณภาพสูง
              สร้างโดยผู้สร้างคอนเทนต์ตัวจริงทั่วประเทศ
            </p>
            <div class="flex items-center gap-2 mt-5">
              <a class="btn-icon" href="#" aria-label="Facebook">
                <svg viewBox="0 0 24 24" class="w-4 h-4" fill="currentColor">
                  <path
                    d="M9.2 22V12.5H6V9h3.2V6.6c0-3.2 1.9-4.9 4.7-4.9 1.4 0 2.6.1 2.9.2v3.4h-2c-1.6 0-1.9.8-1.9 1.9V9h3.7l-.5 3.5h-3.2V22"
                  />
                </svg>
              </a>
              <a class="btn-icon" href="#" aria-label="Instagram">
                <svg viewBox="0 0 24 24" class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="1.6">
                  <rect x="3" y="3" width="18" height="18" rx="5"/>
                  <circle cx="12" cy="12" r="4"/>
                  <circle cx="17.5" cy="6.5" r="0.6" fill="currentColor"/>
                </svg>
              </a>
              <a class="btn-icon" href="#" aria-label="Line">
                <svg viewBox="0 0 24 24" class="w-4 h-4" fill="currentColor">
                  <path d="M12 3C6.5 3 2 6.6 2 11c0 3 2.2 5.6 5.4 7L7 21l3.7-2.1c.4 0 .9.1 1.3.1 5.5 0 10-3.6 10-8s-4.5-8-10-8Z"/>
                </svg>
              </a>
            </div>
          </div>

          <div>
            <h4 class="text-sm font-bold text-ink mb-4">สำรวจ</h4>
            <ul class="space-y-3 text-sm text-ink-soft">
              <li><a routerLink="/marketplace" class="hover:text-pink-600">ตลาดเอกสาร</a></li>
              <li><a routerLink="/categories" class="hover:text-pink-600">หมวดหมู่</a></li>
              <li><a routerLink="/" class="hover:text-pink-600">เอกสารแนะนำ</a></li>
              <li><a routerLink="/" class="hover:text-pink-600">ผู้ขายแนะนำ</a></li>
            </ul>
          </div>

          <div>
            <h4 class="text-sm font-bold text-ink mb-4">เริ่มต้นกับเรา</h4>
            <ul class="space-y-3 text-sm text-ink-soft">
              <li><a routerLink="/seller" class="hover:text-pink-600">เปิดร้าน Siri Studio</a></li>
              <li><a routerLink="/seller/upload" class="hover:text-pink-600">อัปโหลดเอกสาร</a></li>
              <li><a routerLink="/library" class="hover:text-pink-600">คลังของฉัน</a></li>
              <li><a routerLink="/" class="hover:text-pink-600">โปรแกรมพันธมิตร</a></li>
            </ul>
          </div>

          <div>
            <h4 class="text-sm font-bold text-ink mb-4">ช่วยเหลือ</h4>
            <ul class="space-y-3 text-sm text-ink-soft">
              <li><a href="#" class="hover:text-pink-600">ศูนย์ช่วยเหลือ</a></li>
              <li><a href="#" class="hover:text-pink-600">นโยบายความเป็นส่วนตัว</a></li>
              <li><a href="#" class="hover:text-pink-600">เงื่อนไขการใช้งาน</a></li>
              <li>
                <a class="inline-flex items-center gap-1 hover:text-pink-600" href="mailto:hello@siriedumarket.co">
                  <app-icon name="mail" [size]="14" />
                  hello&#64;siriedumarket.co
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div
          class="mt-12 pt-6 border-t border-line flex flex-col md:flex-row items-start md:items-center justify-between gap-3"
        >
          <p class="text-xs text-ink-muted">
            © 2026 SIRIEDUMARKET — Document Studio. All rights reserved.
          </p>
          <div class="flex items-center gap-3 text-xs text-ink-muted">
            <span class="inline-flex items-center gap-1">
              <app-icon name="shield" [size]="12" />
              Watermark Protection
            </span>
            <span class="inline-flex items-center gap-1">
              <app-icon name="lock" [size]="12" />
              SSL Secured
            </span>
            <span class="inline-flex items-center gap-1">
              <app-icon name="qr" [size]="12" />
              PromptPay
            </span>
          </div>
        </div>
      </div>
    </footer>
  `,
})
export class AppFooterComponent {}
