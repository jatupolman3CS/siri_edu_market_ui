import { ChangeDetectionStrategy, Component, output } from '@angular/core';
import { AuthProvider } from '../../core/services';

@Component({
  selector: 'app-social-buttons',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="flex flex-col gap-2.5">
      <!-- Google -->
      <button
        type="button"
        class="flex items-center justify-center gap-3 w-full py-3 rounded-full border border-line bg-white hover:border-pink-300 hover:bg-pink-50/40 font-semibold text-ink text-sm transition-all"
        (click)="select.emit('google')"
      >
        <svg viewBox="0 0 24 24" class="w-5 h-5">
          <path
            fill="#FFC107"
            d="M21.8 10.2H12v3.8h5.6c-.5 2.6-2.7 4.5-5.6 4.5-3.4 0-6.1-2.7-6.1-6.1S8.6 6.3 12 6.3c1.5 0 2.9.5 4 1.5l2.7-2.7C16.9 3.5 14.6 2.6 12 2.6 6.8 2.6 2.6 6.8 2.6 12s4.2 9.4 9.4 9.4c5.4 0 9-3.8 9-9.1 0-.7-.1-1.4-.2-2.1Z"
          />
          <path
            fill="#FF3D00"
            d="m3.7 7 3.1 2.3C7.6 7.2 9.6 6.3 12 6.3c1.5 0 2.9.5 4 1.5l2.7-2.7C16.9 3.5 14.6 2.6 12 2.6 8.4 2.6 5.2 4.7 3.7 7Z"
          />
          <path
            fill="#4CAF50"
            d="M12 21.4c2.5 0 4.7-.9 6.4-2.4l-2.9-2.5c-1 .7-2.2 1.1-3.5 1.1-2.9 0-5.1-1.9-5.6-4.4l-3 2.3c1.5 3 4.6 5 8.6 5Z"
          />
          <path
            fill="#1976D2"
            d="M21.8 10.2H12v3.8h5.6c-.3 1.3-1 2.4-2 3.2l2.9 2.5c1.7-1.6 2.8-3.9 2.8-7.4 0-.7-.1-1.4-.2-2.1Z"
          />
        </svg>
        เข้าสู่ระบบด้วย Google
      </button>

      <!-- Facebook -->
      <button
        type="button"
        class="flex items-center justify-center gap-3 w-full py-3 rounded-full border border-line bg-white hover:border-[#1877F2] hover:bg-[#1877F2]/5 font-semibold text-ink text-sm transition-all"
        (click)="select.emit('facebook')"
      >
        <svg viewBox="0 0 24 24" class="w-5 h-5">
          <path
            fill="#1877F2"
            d="M24 12a12 12 0 1 0-13.9 11.9v-8.4H7.1V12h3v-2.6c0-3 1.8-4.6 4.5-4.6 1.3 0 2.7.2 2.7.2v3h-1.5c-1.5 0-2 .9-2 1.9V12h3.4l-.6 3.5h-2.9V24A12 12 0 0 0 24 12Z"
          />
        </svg>
        เข้าสู่ระบบด้วย Facebook
      </button>

      <!-- LINE -->
      <button
        type="button"
        class="flex items-center justify-center gap-3 w-full py-3 rounded-full border border-line bg-white hover:border-[#06C755] hover:bg-[#06C755]/5 font-semibold text-ink text-sm transition-all"
        (click)="select.emit('line')"
      >
        <svg viewBox="0 0 24 24" class="w-5 h-5">
          <rect x="1" y="1" width="22" height="22" rx="5" fill="#06C755" />
          <path
            fill="white"
            d="M19.4 10.7c0-3.4-3.4-6.1-7.5-6.1S4.5 7.4 4.5 10.7c0 3 2.7 5.5 6.3 6 .2 0 .5.2.6.4l.2 1.1c0 .2.2.7.7.4l3.7-2.4c2.2-1.4 3.4-3.3 3.4-5.5Z"
          />
          <path
            fill="#06C755"
            d="M9 9.4h-.5v3.2h.5v-3.2Zm5.4 0h-.5v2l-1.5-2h-.5v3.2h.5v-2l1.5 2h.5V9.4Zm-2.7 2.7h-1V11h1v-.5h-1v-.7h1v-.4h-1.5v3.2h1.5v-.5Zm5.4-2.7-1.1 1.4-1-1.4h-.6l1.3 1.7v1.5h.5V11l1.4-1.6h-.5Z"
          />
        </svg>
        เข้าสู่ระบบด้วย LINE
      </button>
    </div>
  `,
})
export class SocialButtonsComponent {
  readonly select = output<AuthProvider>();
}
