import { ChangeDetectionStrategy, Component, input } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Bundle } from '../../core/models';
import { ThbPipe } from '../pipes/thb.pipe';
import { CompactPipe } from '../pipes/compact.pipe';
import { IconComponent } from './icon.component';

@Component({
  selector: 'app-bundle-card',
  standalone: true,
  imports: [RouterLink, ThbPipe, CompactPipe, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <article
      class="group relative card-soft overflow-hidden hover:shadow-pop transition-all duration-300 hover:-translate-y-1"
    >
      <a [routerLink]="['/bundle', bundle().id]" class="block">
        <!-- Cover -->
        <div class="relative aspect-[16/10] bg-pink-50 overflow-hidden">
          <img
            [src]="bundle().cover"
            [alt]="bundle().title"
            class="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            loading="lazy"
          />
          <div class="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>

          <!-- Badges -->
          <div class="absolute top-3 left-3 flex gap-2">
            <span class="pill bg-violet-500 text-white shadow-soft">
              📦 BUNDLE
            </span>
            @if (savingsPercent() >= 20) {
              <span class="pill bg-pink-500 text-white shadow-soft">
                ประหยัด {{ savingsPercent() }}%
              </span>
            }
          </div>

          <!-- Item count -->
          <div class="absolute bottom-3 left-3 pill bg-white/90 backdrop-blur text-ink text-xs font-bold">
            {{ bundle().documentIds.length }} เอกสารในแพ็กเกจ
          </div>
        </div>

        <!-- Body -->
        <div class="p-5 flex flex-col gap-2">
          <div class="flex items-center gap-2 text-[11px] text-ink-muted">
            <img
              [src]="bundle().seller.avatar"
              class="w-5 h-5 rounded-full object-cover"
              [alt]="bundle().seller.studioName"
            />
            <span class="truncate">{{ bundle().seller.studioName }}</span>
          </div>

          <h3 class="text-base font-extrabold text-ink leading-snug line-clamp-2 group-hover:text-pink-600 transition-colors">
            {{ bundle().title }}
          </h3>

          <p class="text-xs text-ink-soft line-clamp-2 leading-relaxed">
            {{ bundle().description }}
          </p>

          <div class="flex items-center gap-3 text-xs text-ink-muted">
            <span class="text-pink-600 font-bold">★ {{ bundle().rating }}</span>
            <span>({{ bundle().reviewCount }})</span>
            <span class="inline-flex items-center gap-1">
              <app-icon name="download" [size]="12" />
              {{ bundle().downloads | compact }}
            </span>
          </div>

          <div class="flex items-end justify-between mt-2 pt-3 border-t border-line">
            <div class="flex items-baseline gap-2">
              <span class="text-xl font-extrabold text-ink">
                {{ bundle().price | thb }}
              </span>
              <span class="text-xs text-ink-muted line-through">
                {{ bundle().originalPrice | thb }}
              </span>
            </div>
            <div class="text-emerald-600 font-bold text-xs">
              − {{ savings() | thb }}
            </div>
          </div>
        </div>
      </a>
    </article>
  `,
})
export class BundleCardComponent {
  readonly bundle = input.required<Bundle>();

  savings(): number {
    return this.bundle().originalPrice - this.bundle().price;
  }
  savingsPercent(): number {
    if (this.bundle().originalPrice === 0) return 0;
    return Math.round(
      ((this.bundle().originalPrice - this.bundle().price) /
        this.bundle().originalPrice) *
        100,
    );
  }
}
