import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { IconComponent } from '../../shared/components/icon.component';

@Component({
  selector: 'app-admin-layout',
  standalone: true,
  imports: [
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    IconComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-canvas flex">
      <aside
        class="hidden lg:flex flex-col w-72 bg-ink text-pink-50 p-6 sticky top-0 h-screen"
      >
        <div class="flex items-center gap-2.5">
          <span class="relative flex items-center justify-center w-10 h-10 rounded-2xl bg-gradient-to-br from-pink-300 to-pink-500 shadow-soft">
            <svg viewBox="0 0 24 24" fill="none" class="w-6 h-6 text-white">
              <path d="M12 3 4 6v6c0 5 3.5 8.5 8 9 4.5-.5 8-4 8-9V6l-8-3Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>
              <path d="m9 12 2 2 4-4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </span>
          <div class="leading-none">
            <div class="text-sm font-extrabold">ADMIN PANEL</div>
            <div class="text-[10px] uppercase tracking-[0.2em] text-pink-300 mt-1">SIRIEDUMARKET</div>
          </div>
        </div>

        <div class="mt-3 mb-8 pl-1">
          <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-200 text-[10px] font-bold uppercase tracking-wider">
            <span class="w-1.5 h-1.5 rounded-full bg-rose-300 animate-pulse-soft"></span>
            High access
          </span>
        </div>

        <nav class="flex flex-col gap-1.5 flex-1">
          @for (item of navItems; track item.href) {
            <a
              [routerLink]="item.href"
              routerLinkActive="!bg-white/10 !text-white"
              [routerLinkActiveOptions]="{ exact: item.exact ?? false }"
              class="flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-medium text-pink-100/70 hover:bg-white/5 hover:text-white transition-colors"
            >
              <app-icon [name]="item.icon" [size]="18" />
              <span class="flex-1">{{ item.label }}</span>
              @if (item.badge) {
                <span class="pill bg-pink-500 text-white !py-0 !px-2 !text-[10px]">{{ item.badge }}</span>
              }
            </a>
          }
        </nav>

        <a routerLink="/" class="mt-4 flex items-center gap-2 px-4 py-3 rounded-2xl text-sm text-pink-100/70 hover:bg-white/5 hover:text-white">
          <app-icon name="arrow-left" [size]="16" />
          กลับสู่หน้าตลาด
        </a>
      </aside>

      <!-- Mobile -->
      <header class="lg:hidden sticky top-0 z-20 bg-ink text-white w-full">
        <div class="flex items-center justify-between px-4 h-16">
          <div class="flex items-center gap-2">
            <span class="w-8 h-8 rounded-xl bg-gradient-to-br from-pink-300 to-pink-500"></span>
            <span class="text-sm font-bold">ADMIN</span>
          </div>
          <a routerLink="/" class="text-xs text-pink-200">ออก →</a>
        </div>
        <nav class="flex overflow-x-auto px-4 pb-3 gap-2">
          @for (item of navItems; track item.href) {
            <a
              [routerLink]="item.href"
              routerLinkActive="!bg-pink-500"
              [routerLinkActiveOptions]="{ exact: item.exact ?? false }"
              class="px-3 py-1.5 rounded-full bg-white/10 text-pink-100 text-xs whitespace-nowrap"
            >
              {{ item.label }}
            </a>
          }
        </nav>
      </header>

      <main class="flex-1 min-w-0">
        <div class="p-6 lg:p-10">
          <router-outlet />
        </div>
      </main>
    </div>
  `,
})
export class AdminLayoutComponent {
  readonly navItems = [
    { label: 'ภาพรวม', href: '/admin', icon: 'dashboard' as const, exact: true },
    { label: 'อนุมัติเอกสาร', href: '/admin/approval', icon: 'shield' as const, badge: '4' },
    { label: 'ธุรกรรม', href: '/admin/transactions', icon: 'wallet' as const },
    { label: 'ผู้ขาย', href: '/admin/sellers', icon: 'user' as const },
    { label: 'หมวดหมู่', href: '/admin/categories', icon: 'tag' as const },
    { label: 'ตั้งค่าแพลตฟอร์ม', href: '/admin/settings', icon: 'gear' as const },
  ];
}
