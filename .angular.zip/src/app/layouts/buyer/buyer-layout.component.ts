import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AppHeaderComponent } from '../../shared/components/app-header.component';
import { AppFooterComponent } from '../../shared/components/app-footer.component';
import { CartDrawerComponent } from '../../shared/components/cart-drawer.component';
import { QuickViewModalComponent } from '../../shared/components/quick-view-modal.component';

@Component({
  selector: 'app-buyer-layout',
  standalone: true,
  imports: [
    RouterOutlet,
    AppHeaderComponent,
    AppFooterComponent,
    CartDrawerComponent,
    QuickViewModalComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen flex flex-col bg-canvas">
      <app-header />
      <main class="flex-1">
        <router-outlet />
      </main>
      <app-footer />
      <app-cart-drawer />
      <app-quick-view-modal />
    </div>
  `,
})
export class BuyerLayoutComponent {}
