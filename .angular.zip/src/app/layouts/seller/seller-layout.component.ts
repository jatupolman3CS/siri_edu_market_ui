import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { LogoComponent } from '../../shared/components/logo.component';
import { IconComponent } from '../../shared/components/icon.component';
import { AuthService } from '../../core/services';

@Component({
  selector: 'app-seller-layout',
  standalone: true,
  imports: [
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    LogoComponent,
    IconComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen bg-canvas flex">
      <!-- Sidebar -->
      <aside
        class="hidden lg:flex flex-col w-72 bg-white border-r border-line p-6 sticky top-0 h-screen"
      >
        <app-logo link="/seller" />

        <div class="mt-3 mb-8 pl-1">
          <span class="pill-pink !text-[10px]">
            <app-icon name="dashboard" [size]="11" />
            STUDIO MODE
          </span>
        </div>

        <nav class="flex flex-col gap-1.5 flex-1">
          @for (item of navItems; track item.href) {
            <a
              [routerLink]="item.href"
              routerLinkActive="!bg-pink-50 !text-pink-600 !border-pink-200"
              [routerLinkActiveOptions]="{ exact: item.exact ?? false }"
              class="flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-medium text-ink-soft border border-transparent hover:bg-pink-50 hover:text-pink-600 transition-colors"
            >
              <app-icon [name]="item.icon" [size]="18" />
              <span class="flex-1">{{ item.label }}</span>
              @if (item.badge) {
                <span class="pill-pink !py-0 !px-2">{{ item.badge }}</span>
              }
            </a>
          }
        </nav>

        <a
          routerLink="/"
          class="mt-4 flex items-center gap-2 px-4 py-3 rounded-2xl text-sm text-ink-muted hover:bg-pink-50 hover:text-pink-600"
        >
          <app-icon name="arrow-left" [size]="16" />
          กลับสู่หน้าตลาด
        </a>

        @if (auth.user(); as u) {
          <div
            class="mt-4 flex items-center gap-3 p-3 rounded-2xl bg-pink-50 border border-line"
          >
            <img
              [src]="u.avatar"
              class="w-10 h-10 rounded-full object-cover ring-2 ring-white"
              [alt]="u.name"
            />
            <div class="flex-1 min-w-0">
              <div class="text-sm font-bold text-ink truncate">{{ u.name }}</div>
              <div class="text-xs text-ink-muted truncate">Siri Studio</div>
            </div>
          </div>
        }
      </aside>

      <!-- Mobile top bar -->
      <header
        class="lg:hidden sticky top-0 z-20 bg-white border-b border-line w-full"
      >
        <div class="flex items-center justify-between px-4 h-16">
          <app-logo link="/seller" />
          <a routerLink="/" class="btn-ghost !py-2 !px-4 text-xs">
            ออกจาก Studio
          </a>
        </div>
        <nav class="flex overflow-x-auto px-4 pb-3 gap-2">
          @for (item of navItems; track item.href) {
            <a
              [routerLink]="item.href"
              routerLinkActive="!bg-pink-500 !text-white"
              [routerLinkActiveOptions]="{ exact: item.exact ?? false }"
              class="px-3 py-1.5 rounded-full bg-pink-50 text-ink-soft text-xs font-medium whitespace-nowrap"
            >
              {{ item.label }}
            </a>
          }
        </nav>
      </header>

      <!-- Main -->
      <main class="flex-1 min-w-0">
        <div class="p-6 lg:p-10">
          <router-outlet />
        </div>
      </main>
    </div>
  `,
})
export class SellerLayoutComponent {
  readonly auth = inject(AuthService);

  readonly navItems = [
    { label: 'ภาพรวม', href: '/seller', icon: 'dashboard' as const, exact: true },
    { label: 'เอกสารของฉัน', href: '/seller/documents', icon: 'doc' as const, badge: '8' },
    { label: 'อัปโหลดเอกสาร', href: '/seller/upload', icon: 'upload' as const },
    { label: 'AI Assistant', href: '/seller/ai', icon: 'sparkle' as const },
    { label: 'รายได้ & Payout', href: '/seller/earnings', icon: 'wallet' as const },
    { label: 'รีวิวลูกค้า', href: '/seller/reviews', icon: 'star' as const },
    { label: 'ตั้งค่าร้าน', href: '/seller/settings', icon: 'gear' as const },
  ];
}
