import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { LibraryService } from '../../core/services';
import { PageHeroComponent } from '../../shared/components/page-hero.component';
import { IconComponent } from '../../shared/components/icon.component';
import { EmptyStateComponent } from '../../shared/components/empty-state.component';
import { StatCardComponent } from '../../shared/components/stat-card.component';
import { ThbPipe } from '../../shared/pipes/thb.pipe';
import { TimeAgoPipe } from '../../shared/pipes/time-ago.pipe';
import { CompactPipe } from '../../shared/pipes/compact.pipe';

@Component({
  selector: 'app-buyer-library',
  standalone: true,
  imports: [
    RouterLink,
    PageHeroComponent,
    IconComponent,
    EmptyStateComponent,
    StatCardComponent,
    ThbPipe,
    TimeAgoPipe,
    CompactPipe,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-7xl mx-auto px-4 lg:px-6 py-8">
      <app-page-hero
        eyebrow="คลังของฉัน"
        title="เอกสารที่คุณซื้อทั้งหมด"
        description="ดาวน์โหลดได้ตลอดเวลา ทุกไฟล์มีลายน้ำเฉพาะคุณเพื่อความปลอดภัย"
      />

      <!-- Stats -->
      <section class="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        <app-stat-card
          label="เอกสารที่ซื้อ"
          [value]="library.totalDocuments() + ' เล่ม'"
          icon="📚"
        />
        <app-stat-card
          label="ดาวน์โหลด"
          [value]="(library.totalDownloads() | compact) + ' ครั้ง'"
          icon="⬇️"
        />
        <app-stat-card
          label="ใช้จ่ายรวม"
          [value]="library.totalSpent() | thb"
          icon="💸"
        />
        <app-stat-card
          label="คะแนนสะสม"
          value="1,840 pt"
          icon="🌸"
          trend="+120"
          trendLabel="ในเดือนนี้"
        />
      </section>

      <!-- Tabs -->
      <div class="flex items-center gap-2 mb-6">
        @for (t of tabs; track t.value) {
          <button
            class="px-4 py-2.5 rounded-full text-sm font-medium transition-colors"
            [class.bg-pink-500]="tab() === t.value"
            [class.text-white]="tab() === t.value"
            [class.bg-white]="tab() !== t.value"
            [class.text-ink-soft]="tab() !== t.value"
            [class.border]="tab() !== t.value"
            [class.border-line]="tab() !== t.value"
            (click)="tab.set(t.value)"
          >
            {{ t.label }}
          </button>
        }
      </div>

      @if (library.library().length === 0) {
        <app-empty-state
          emoji="📚"
          title="คลังของคุณยังว่างอยู่"
          description="เริ่มต้นเลือกซื้อเอกสารแรกได้เลย"
        >
          <a routerLink="/marketplace" class="btn-pink mt-4">เริ่มเลือกซื้อ</a>
        </app-empty-state>
      } @else {
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          @for (item of library.library(); track item.document.id) {
            <article class="card-soft overflow-hidden flex flex-col">
              <div class="relative aspect-[4/3] bg-pink-50">
                <img
                  [src]="item.document.cover"
                  [alt]="item.document.title"
                  class="absolute inset-0 w-full h-full object-cover"
                />
                <span
                  class="absolute top-3 left-3 pill bg-white/90 backdrop-blur uppercase text-[10px] font-bold text-ink"
                >
                  {{ item.document.format }}
                </span>
                <span
                  class="absolute top-3 right-3 pill bg-emerald-500 text-white shadow-soft"
                >
                  <app-icon name="check" [size]="11" />
                  เป็นเจ้าของแล้ว
                </span>
              </div>
              <div class="p-5 flex flex-col gap-2 flex-1">
                <span class="text-[11px] text-ink-muted">
                  {{ item.document.seller.studioName }}
                </span>
                <h3 class="text-base font-bold text-ink leading-snug line-clamp-2">
                  {{ item.document.title }}
                </h3>

                <dl class="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-ink-muted mt-2">
                  <div>เลขที่คำสั่งซื้อ</div>
                  <div class="text-ink font-semibold">{{ item.orderNumber }}</div>
                  <div>ซื้อเมื่อ</div>
                  <div class="text-ink">{{ item.purchasedAt | timeAgo }}</div>
                  <div>ดาวน์โหลด</div>
                  <div class="text-ink">{{ item.downloadCount }} ครั้ง</div>
                </dl>

                <div class="flex gap-2 mt-auto pt-4">
                  <a
                    [routerLink]="['/document', item.document.id]"
                    class="btn-ghost flex-1 !py-2.5 text-sm"
                  >
                    <app-icon name="eye" [size]="14" />
                    รายละเอียด
                  </a>
                  <button
                    class="btn-pink flex-1 !py-2.5 text-sm"
                    (click)="library.download(item.document.id)"
                  >
                    <app-icon name="download" [size]="14" />
                    ดาวน์โหลด
                  </button>
                </div>
              </div>
            </article>
          }
        </div>
      }
    </div>
  `,
})
export class BuyerLibraryPage {
  readonly library = inject(LibraryService);

  readonly tab = signal<'all' | 'recent'>('all');
  readonly tabs = [
    { value: 'all' as const, label: 'ทั้งหมด' },
    { value: 'recent' as const, label: 'เพิ่งดาวน์โหลด' },
  ];
}
