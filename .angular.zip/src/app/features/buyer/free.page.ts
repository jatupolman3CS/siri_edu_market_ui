import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CatalogService } from '../../core/services';
import { PageHeroComponent } from '../../shared/components/page-hero.component';
import { DocumentCardComponent } from '../../shared/components/document-card.component';
import { EmptyStateComponent } from '../../shared/components/empty-state.component';
import { IconComponent } from '../../shared/components/icon.component';
import { CompactPipe } from '../../shared/pipes/compact.pipe';

@Component({
  selector: 'app-buyer-free',
  standalone: true,
  imports: [
    PageHeroComponent,
    DocumentCardComponent,
    EmptyStateComponent,
    IconComponent,
    CompactPipe,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-7xl mx-auto px-4 lg:px-6 py-8">
      <app-page-hero
        eyebrow="ฟรี · 100%"
        title="เอกสารดีๆ ที่ดาวน์โหลดได้ฟรี 🎁"
        description="ครีเอเตอร์ของเราแชร์เอกสารคุณภาพให้ใช้ฟรี — ลองใช้ก่อนตัดสินใจซื้อเล่มเต็ม"
      >
        <div class="flex flex-wrap items-center gap-4 mt-6">
          <div class="card-soft px-5 py-3 inline-flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center">
              <app-icon name="download" [size]="18" />
            </span>
            <div>
              <div class="text-xs text-ink-muted">ดาวน์โหลดรวม</div>
              <div class="text-base font-bold text-ink">
                {{ totalDownloads() | compact }} ครั้ง
              </div>
            </div>
          </div>
          <div class="card-soft px-5 py-3 inline-flex items-center gap-3">
            <span class="w-10 h-10 rounded-xl bg-pink-100 text-pink-600 flex items-center justify-center">
              <app-icon name="package" [size]="18" />
            </span>
            <div>
              <div class="text-xs text-ink-muted">เอกสารฟรีทั้งหมด</div>
              <div class="text-base font-bold text-ink">{{ catalog.freeResources().length }} ชิ้น</div>
            </div>
          </div>
        </div>
      </app-page-hero>

      @if (catalog.freeResources().length === 0) {
        <app-empty-state emoji="🎁" title="ตอนนี้ยังไม่มีเอกสารฟรี" />
      } @else {
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          @for (doc of catalog.freeResources(); track doc.id) {
            <app-document-card [doc]="doc" />
          }
        </div>
      }
    </div>
  `,
})
export class BuyerFreePage {
  readonly catalog = inject(CatalogService);

  totalDownloads(): number {
    return this.catalog
      .freeResources()
      .reduce((sum, d) => sum + d.downloads, 0);
  }
}
