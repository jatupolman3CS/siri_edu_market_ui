import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { BundleService } from '../../core/services';
import { PageHeroComponent } from '../../shared/components/page-hero.component';
import { BundleCardComponent } from '../../shared/components/bundle-card.component';
import { EmptyStateComponent } from '../../shared/components/empty-state.component';

@Component({
  selector: 'app-buyer-bundles',
  standalone: true,
  imports: [PageHeroComponent, BundleCardComponent, EmptyStateComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-7xl mx-auto px-4 lg:px-6 py-8">
      <app-page-hero
        eyebrow="แพ็กเกจคุ้มสุดคุ้ม"
        title="ซื้อชุดคุ้มกว่า ใช้ได้ครบทั้งคอร์ส 📦"
        description="รวมเอกสารและเทมเพลตที่เข้าคู่กัน ราคาประหยัดกว่าซื้อแยกถึง 40%"
      />

      @if (bundleService.bundles().length === 0) {
        <app-empty-state
          emoji="📦"
          title="ยังไม่มีแพ็กเกจ"
          description="ตอนนี้ยังไม่มีแพ็กเกจที่เปิดขาย"
        />
      } @else {
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          @for (bundle of bundleService.bundles(); track bundle.id) {
            <app-bundle-card [bundle]="bundle" />
          }
        </div>
      }
    </div>
  `,
})
export class BuyerBundlesPage {
  readonly bundleService = inject(BundleService);
}
