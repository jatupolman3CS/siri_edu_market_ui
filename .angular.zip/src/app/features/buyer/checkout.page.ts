import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CartService } from '../../core/services';
import { ThbPipe } from '../../shared/pipes/thb.pipe';
import { IconComponent } from '../../shared/components/icon.component';
import { EmptyStateComponent } from '../../shared/components/empty-state.component';

type PayMethod = 'promptpay' | 'credit_card' | 'truemoney';

@Component({
  selector: 'app-buyer-checkout',
  standalone: true,
  imports: [RouterLink, FormsModule, ThbPipe, IconComponent, EmptyStateComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-6xl mx-auto px-4 lg:px-6 py-10">
      <h1 class="text-3xl font-extrabold text-ink mb-2">ชำระเงิน</h1>
      <p class="text-sm text-ink-muted mb-8">
        ตรวจสอบรายการและเลือกวิธีการชำระเงินที่คุณสะดวก
      </p>

      @if (cart.count() === 0) {
        <app-empty-state
          emoji="🛍️"
          title="ตะกร้าของคุณว่างอยู่"
          description="กลับไปเลือกซื้อเอกสารกันก่อน"
        >
          <a routerLink="/marketplace" class="btn-pink mt-4">เลือกเอกสาร</a>
        </app-empty-state>
      } @else {
        <div class="grid lg:grid-cols-3 gap-6">
          <!-- Left: Items + payment -->
          <div class="lg:col-span-2 space-y-6">
            <!-- Items -->
            <section class="card-soft p-6">
              <h2 class="text-lg font-bold text-ink mb-4 flex items-center gap-2">
                <span class="w-7 h-7 rounded-full bg-pink-100 text-pink-600 text-xs font-bold flex items-center justify-center">1</span>
                รายการสินค้า
              </h2>
              <ul class="flex flex-col gap-3">
                @for (item of cart.items(); track item.document.id) {
                  <li class="flex gap-4 items-center">
                    <img
                      [src]="item.document.cover"
                      [alt]="item.document.title"
                      class="w-16 h-20 rounded-xl object-cover flex-shrink-0"
                    />
                    <div class="flex-1 min-w-0">
                      <div class="text-xs text-ink-muted">{{ item.document.seller.studioName }}</div>
                      <div class="text-sm font-bold text-ink line-clamp-1">{{ item.document.title }}</div>
                      <div class="text-xs text-ink-muted mt-0.5 uppercase">{{ item.document.format }} · {{ item.document.pages }} หน้า</div>
                    </div>
                    <div class="text-right">
                      <div class="text-base font-bold text-pink-600">{{ item.document.price | thb }}</div>
                      <button
                        class="text-xs text-ink-muted hover:text-rose-500 mt-1"
                        (click)="cart.remove(item.document.id)"
                      >
                        ลบ
                      </button>
                    </div>
                  </li>
                }
              </ul>
            </section>

            <!-- Payment method -->
            <section class="card-soft p-6">
              <h2 class="text-lg font-bold text-ink mb-4 flex items-center gap-2">
                <span class="w-7 h-7 rounded-full bg-pink-100 text-pink-600 text-xs font-bold flex items-center justify-center">2</span>
                วิธีการชำระเงิน
              </h2>
              <div class="grid sm:grid-cols-3 gap-3">
                @for (m of methods; track m.value) {
                  <label
                    class="relative cursor-pointer"
                  >
                    <input
                      type="radio"
                      name="paymethod"
                      [value]="m.value"
                      [checked]="payMethod() === m.value"
                      (change)="payMethod.set(m.value)"
                      class="absolute opacity-0"
                    />
                    <div
                      class="p-4 rounded-2xl border-2 transition-all"
                      [class.border-pink-500]="payMethod() === m.value"
                      [class.bg-pink-50]="payMethod() === m.value"
                      [class.border-line]="payMethod() !== m.value"
                    >
                      <div class="flex items-center justify-between mb-2">
                        <span class="text-2xl">{{ m.icon }}</span>
                        @if (payMethod() === m.value) {
                          <span class="w-5 h-5 rounded-full bg-pink-500 text-white flex items-center justify-center">
                            <app-icon name="check" [size]="12" />
                          </span>
                        }
                      </div>
                      <div class="text-sm font-semibold text-ink">{{ m.label }}</div>
                      <div class="text-xs text-ink-muted mt-0.5">{{ m.note }}</div>
                    </div>
                  </label>
                }
              </div>

              <!-- Method specific UI -->
              <div class="mt-6">
                @switch (payMethod()) {
                  @case ('promptpay') {
                    <div class="flex flex-col sm:flex-row items-center gap-6 p-6 rounded-3xl bg-pink-50 border border-line">
                      <div class="w-44 h-44 rounded-2xl bg-white p-3 shadow-soft flex items-center justify-center">
                        <!-- QR placeholder -->
                        <svg viewBox="0 0 100 100" class="w-full h-full">
                          <rect width="100" height="100" fill="white"/>
                          <g fill="black">
                            <rect x="5"  y="5"  width="20" height="20"/>
                            <rect x="75" y="5"  width="20" height="20"/>
                            <rect x="5"  y="75" width="20" height="20"/>
                            <rect x="10" y="10" width="10" height="10" fill="white"/>
                            <rect x="80" y="10" width="10" height="10" fill="white"/>
                            <rect x="10" y="80" width="10" height="10" fill="white"/>
                            <rect x="35" y="10" width="6" height="6"/>
                            <rect x="45" y="10" width="6" height="6"/>
                            <rect x="55" y="10" width="6" height="6"/>
                            <rect x="35" y="35" width="6" height="6"/>
                            <rect x="45" y="35" width="6" height="6"/>
                            <rect x="60" y="40" width="6" height="6"/>
                            <rect x="35" y="50" width="6" height="6"/>
                            <rect x="55" y="55" width="6" height="6"/>
                            <rect x="40" y="65" width="6" height="6"/>
                            <rect x="50" y="70" width="6" height="6"/>
                            <rect x="60" y="60" width="6" height="6"/>
                            <rect x="70" y="65" width="6" height="6"/>
                            <rect x="80" y="55" width="6" height="6"/>
                            <rect x="85" y="40" width="6" height="6"/>
                            <rect x="40" y="80" width="6" height="6"/>
                            <rect x="55" y="80" width="6" height="6"/>
                            <rect x="70" y="80" width="6" height="6"/>
                            <rect x="80" y="80" width="6" height="6"/>
                          </g>
                        </svg>
                      </div>
                      <div class="text-center sm:text-left">
                        <div class="pill-pink mb-2">
                          <app-icon name="qr" [size]="12" /> PromptPay
                        </div>
                        <h3 class="text-lg font-bold text-ink mb-1">สแกน QR เพื่อชำระ</h3>
                        <p class="text-sm text-ink-soft mb-3 max-w-sm">
                          เปิดแอปธนาคารและสแกน QR Code ระบบจะยืนยันการชำระเงินอัตโนมัติภายใน 30 วินาที
                        </p>
                        <div class="text-2xl font-extrabold text-ink">{{ cart.total() | thb }}</div>
                        <div class="text-xs text-ink-muted mt-1">QR หมดอายุใน 4:59 นาที</div>
                      </div>
                    </div>
                  }

                  @case ('credit_card') {
                    <div class="grid sm:grid-cols-2 gap-4">
                      <div class="sm:col-span-2">
                        <label class="text-xs font-semibold text-ink-soft mb-2 block">เลขบัตร</label>
                        <input class="input-soft" placeholder="1234 5678 9012 3456" />
                      </div>
                      <div>
                        <label class="text-xs font-semibold text-ink-soft mb-2 block">วันหมดอายุ</label>
                        <input class="input-soft" placeholder="MM/YY" />
                      </div>
                      <div>
                        <label class="text-xs font-semibold text-ink-soft mb-2 block">CVV</label>
                        <input class="input-soft" placeholder="123" type="password" />
                      </div>
                      <div class="sm:col-span-2">
                        <label class="text-xs font-semibold text-ink-soft mb-2 block">ชื่อบนบัตร</label>
                        <input class="input-soft" placeholder="PICHAYA P." />
                      </div>
                    </div>
                  }

                  @case ('truemoney') {
                    <div class="p-6 rounded-3xl bg-pink-50 border border-line">
                      <div class="flex items-center gap-3 mb-3">
                        <span class="text-2xl">📱</span>
                        <h3 class="text-base font-bold text-ink">TrueMoney Wallet</h3>
                      </div>
                      <p class="text-sm text-ink-soft mb-4">
                        ระบุเบอร์โทรศัพท์ที่ผูกกับ TrueMoney Wallet
                      </p>
                      <input class="input-soft" placeholder="08X-XXX-XXXX" />
                    </div>
                  }
                }
              </div>
            </section>
          </div>

          <!-- Summary -->
          <aside class="lg:col-span-1">
            <div class="card-soft p-6 sticky top-[88px]">
              <h2 class="text-base font-bold text-ink mb-4">สรุปการสั่งซื้อ</h2>
              <dl class="space-y-2 text-sm">
                <div class="flex justify-between text-ink-soft">
                  <dt>ยอดสินค้า ({{ cart.count() }})</dt>
                  <dd>{{ cart.subtotal() | thb }}</dd>
                </div>
                @if (cart.savings() > 0) {
                  <div class="flex justify-between text-emerald-600">
                    <dt>ส่วนลดสะสม</dt>
                    <dd>- {{ cart.savings() | thb }}</dd>
                  </div>
                }
                <div class="flex justify-between text-ink-soft">
                  <dt>VAT 7%</dt>
                  <dd>{{ cart.tax() | thb }}</dd>
                </div>
                <div class="border-t border-line pt-3 flex justify-between text-base font-bold text-ink">
                  <dt>ยอดรวม</dt>
                  <dd class="text-pink-600">{{ cart.total() | thb }}</dd>
                </div>
              </dl>

              <button
                class="btn-pink w-full !py-3.5 mt-5 text-base"
                (click)="confirmPayment()"
              >
                <app-icon name="lock" [size]="16" />
                ยืนยันการชำระเงิน
              </button>

              <p class="text-[11px] text-ink-muted text-center mt-3 leading-relaxed">
                เมื่อกดยืนยัน คุณยอมรับ <a href="#" class="text-pink-600">เงื่อนไขการใช้งาน</a>
                และ <a href="#" class="text-pink-600">นโยบายความเป็นส่วนตัว</a>
              </p>

              <div class="grid grid-cols-3 gap-2 mt-5 pt-5 border-t border-line text-center text-xs">
                <div class="flex flex-col items-center gap-1">
                  <span class="text-pink-500">
                    <app-icon name="lock" [size]="16" />
                  </span>
                  <span class="text-ink-muted">SSL Secure</span>
                </div>
                <div class="flex flex-col items-center gap-1">
                  <span class="text-pink-500">
                    <app-icon name="shield" [size]="16" />
                  </span>
                  <span class="text-ink-muted">Watermarked</span>
                </div>
                <div class="flex flex-col items-center gap-1">
                  <span class="text-pink-500">
                    <app-icon name="download" [size]="16" />
                  </span>
                  <span class="text-ink-muted">Instant DL</span>
                </div>
              </div>
            </div>
          </aside>
        </div>
      }
    </div>
  `,
})
export class BuyerCheckoutPage {
  readonly cart = inject(CartService);
  private readonly router = inject(Router);

  readonly payMethod = signal<PayMethod>('promptpay');

  readonly methods: { value: PayMethod; label: string; icon: string; note: string }[] =
    [
      { value: 'promptpay', label: 'PromptPay QR', icon: '📲', note: 'สแกนจ่ายทันที' },
      { value: 'credit_card', label: 'บัตรเครดิต', icon: '💳', note: 'Visa / Master / JCB' },
      { value: 'truemoney', label: 'TrueMoney', icon: '👛', note: 'หักจาก e-Wallet' },
    ];

  confirmPayment(): void {
    // Mock success
    this.cart.clear();
    this.router.navigate(['/orders'], {
      queryParams: { success: 1 },
    });
  }
}
