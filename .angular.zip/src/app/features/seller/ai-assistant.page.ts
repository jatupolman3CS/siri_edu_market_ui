import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IconComponent } from '../../shared/components/icon.component';

@Component({
  selector: 'app-seller-ai',
  standalone: true,
  imports: [FormsModule, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-5xl">
      <header class="mb-8">
        <span class="pill-pink mb-3">
          <app-icon name="sparkle" [size]="11" /> Powered by Gemini
        </span>
        <h1 class="text-3xl font-extrabold text-ink mb-1">
          AI Assistant สำหรับผู้ขาย ✨
        </h1>
        <p class="text-sm text-ink-soft">
          ใช้ AI ช่วยสรุปเนื้อหาเอกสาร 3 ข้อ และเขียนคำอธิบายสินค้าให้น่าสนใจ
        </p>
      </header>

      <!-- Tools -->
      <div class="grid md:grid-cols-3 gap-4 mb-8">
        @for (t of tools; track t.id) {
          <button
            type="button"
            class="card-soft p-5 text-left transition-all"
            [class.!border-pink-300]="active() === t.id"
            [class.shadow-pop]="active() === t.id"
            (click)="active.set(t.id)"
          >
            <div class="w-12 h-12 rounded-2xl bg-gradient-to-br from-pink-300 to-pink-500 text-white flex items-center justify-center mb-3 text-xl">
              {{ t.icon }}
            </div>
            <h3 class="text-base font-bold text-ink mb-1">{{ t.title }}</h3>
            <p class="text-xs text-ink-soft leading-relaxed">{{ t.desc }}</p>
          </button>
        }
      </div>

      <div class="grid lg:grid-cols-2 gap-6">
        <!-- Input -->
        <section class="card-soft p-6">
          <h2 class="text-base font-bold text-ink mb-4">ข้อมูลเอกสาร</h2>

          <div class="space-y-4">
            <div>
              <label class="text-xs font-semibold text-ink-soft mb-2 block">เลือกเอกสารของคุณ</label>
              <select [(ngModel)]="selectedDoc" class="input-soft cursor-pointer">
                <option value="">— เอกสารทั้งหมด —</option>
                <option value="doc-001">สรุปคณิตม.ปลาย ครบ 6 บท</option>
                <option value="doc-002">แผนธุรกิจ Startup Template</option>
                <option value="doc-003">Clean Architecture .NET</option>
              </select>
            </div>

            <div>
              <label class="text-xs font-semibold text-ink-soft mb-2 block">หรือวางเนื้อหาบางส่วน</label>
              <textarea
                rows="8"
                [(ngModel)]="content"
                class="input-soft"
                placeholder="วางข้อความบางส่วนของเอกสารหรือสารบัญที่นี่ AI จะวิเคราะห์ให้คุณ…"
              ></textarea>
            </div>

            <div>
              <label class="text-xs font-semibold text-ink-soft mb-2 block">โทนเสียงที่ต้องการ</label>
              <div class="flex flex-wrap gap-2">
                @for (t of tones; track t) {
                  <button
                    class="px-4 py-2 rounded-full text-sm font-medium border transition-colors"
                    [class.border-pink-500]="tone() === t"
                    [class.bg-pink-50]="tone() === t"
                    [class.text-pink-600]="tone() === t"
                    [class.border-line]="tone() !== t"
                    [class.text-ink-soft]="tone() !== t"
                    (click)="tone.set(t)"
                  >
                    {{ t }}
                  </button>
                }
              </div>
            </div>

            <button
              class="btn-pink w-full !py-3 text-base"
              (click)="generate()"
              [disabled]="loading()"
            >
              @if (loading()) {
                <span class="inline-block animate-spin">✦</span>
                AI กำลังคิด…
              } @else {
                <app-icon name="sparkle" [size]="16" />
                สร้างผลลัพธ์
              }
            </button>
          </div>
        </section>

        <!-- Output -->
        <section class="card-soft p-6 bg-gradient-pink">
          <header class="flex items-center justify-between mb-4">
            <h2 class="text-base font-bold text-ink flex items-center gap-2">
              <app-icon name="sparkle" [size]="16" className="text-pink-500" />
              ผลลัพธ์จาก AI
            </h2>
            @if (result()) {
              <button class="text-xs text-pink-600 font-bold hover:underline" (click)="copy()">
                คัดลอก
              </button>
            }
          </header>

          @if (!result() && !loading()) {
            <div class="flex flex-col items-center justify-center text-center py-12">
              <div class="w-20 h-20 rounded-3xl bg-white shadow-soft flex items-center justify-center text-4xl mb-4">
                ✨
              </div>
              <h3 class="text-base font-bold text-ink mb-1">เริ่มจากเครื่องมือซ้ายมือ</h3>
              <p class="text-xs text-ink-muted max-w-xs">
                เลือกเครื่องมือ ใส่เนื้อหา จากนั้นกด "สร้างผลลัพธ์"
              </p>
            </div>
          } @else if (loading()) {
            <div class="space-y-3 animate-pulse">
              <div class="h-3 rounded-full bg-white/60 w-4/5"></div>
              <div class="h-3 rounded-full bg-white/60 w-full"></div>
              <div class="h-3 rounded-full bg-white/60 w-3/5"></div>
              <div class="h-3 rounded-full bg-white/60 w-4/5"></div>
            </div>
          } @else if (result(); as r) {
            <div class="bg-white rounded-2xl p-5 text-sm text-ink leading-relaxed whitespace-pre-line">
              {{ r }}
            </div>
            <div class="flex items-center gap-2 mt-4 text-xs text-ink-muted">
              <app-icon name="sparkle" [size]="11" />
              <span>สร้างโดย Gemini API · คุณปรับแก้เป็นสไตล์ตัวเองได้</span>
            </div>
          }
        </section>
      </div>
    </div>
  `,
})
export class SellerAiAssistantPage {
  readonly tools = [
    { id: 'summary', icon: '📝', title: 'สรุปเนื้อหา 3 ข้อ', desc: 'AI สกัดสาระสำคัญ 3 ข้อจากเอกสาร แสดงในหน้ารายละเอียด' },
    { id: 'description', icon: '✍️', title: 'เขียนคำอธิบาย', desc: 'สร้างคำอธิบายสินค้าให้น่าสนใจ ดึงดูดผู้ซื้อ' },
    { id: 'tags', icon: '🏷️', title: 'แนะนำแท็ก & ราคา', desc: 'AI แนะนำแท็กและช่วงราคาที่เหมาะสมตามตลาด' },
  ];

  readonly tones = ['เป็นมิตร', 'มืออาชีพ', 'สนุกสนาน', 'จริงจัง'];

  readonly active = signal<string>('summary');
  readonly selectedDoc = signal<string>('');
  readonly content = signal<string>('');
  readonly tone = signal<string>('เป็นมิตร');
  readonly loading = signal<boolean>(false);
  readonly result = signal<string>('');

  generate(): void {
    this.loading.set(true);
    this.result.set('');
    setTimeout(() => {
      this.loading.set(false);
      this.result.set(this.fakeResponse());
    }, 1400);
  }

  private fakeResponse(): string {
    switch (this.active()) {
      case 'summary':
        return `1. ครอบคลุมเนื้อหาคณิตศาสตร์ม.ปลาย 6 บทใหญ่ พร้อมตัวอย่างโจทย์ที่ออกสอบบ่อย

2. มีโจทย์ฝึก 120 ข้อ จัดเรียงตามระดับความยาก พร้อมเฉลยละเอียดทุกข้อ

3. รูปแบบเล่มออกแบบให้อ่านง่าย ตัวอักษรชัดเจน เหมาะสำหรับใช้ทบทวนก่อนสอบ A-Level / TGAT`;
      case 'description':
        return `📚 อยากเตรียมสอบให้พร้อมโดยไม่เสียเวลา? เอกสารชุดนี้รวมเนื้อหาที่ครูติวเตอร์มืออาชีพคัดมาให้แล้วทั้งหมด ครอบคลุมทุกบทที่ออกสอบบ่อย พร้อมแบบฝึกหัด 120 ข้อพร้อมเฉลย

✨ จุดเด่น:
- ใช้สีสันและภาพช่วยจำ — เห็นปั๊บเข้าใจปุ๊บ
- โจทย์ครอบคลุมตั้งแต่ระดับพื้นฐานจนถึงสนามสอบจริง
- ฟอนต์อ่านสบาย พิมพ์ลงกระดาษ A4 ก็สวย

ใช้สำหรับ: เตรียมสอบ A-Level, TGAT, มหิดล, จุฬา ฯลฯ`;
      case 'tags':
      default:
        return `🏷️ แท็กแนะนำ:
#คณิตม.ปลาย #ติวเข้ม #A-Level #TGAT #สรุปเนื้อหา #เตรียมสอบ #คณิตศาสตร์

💰 ช่วงราคาที่แนะนำ: ฿179–฿259
- ราคาเฉลี่ยในหมวดเดียวกัน: ฿199
- คู่แข่งช่วง 4.5★ ขึ้นไป: ฿229
- เริ่มต้นที่ ฿179 เพื่อเก็บรีวิว 5★ ก่อน แล้วค่อยปรับขึ้นเป็น ฿229`;
    }
  }

  copy(): void {
    navigator.clipboard?.writeText(this.result());
  }
}
