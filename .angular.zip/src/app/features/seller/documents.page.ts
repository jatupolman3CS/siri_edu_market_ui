import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';
import { SellerService } from '../../core/services';
import { IconComponent } from '../../shared/components/icon.component';
import { ThbPipe } from '../../shared/pipes/thb.pipe';
import { CompactPipe } from '../../shared/pipes/compact.pipe';
import { TimeAgoPipe } from '../../shared/pipes/time-ago.pipe';

@Component({
  selector: 'app-seller-documents',
  standalone: true,
  imports: [
    RouterLink,
    FormsModule,
    IconComponent,
    ThbPipe,
    CompactPipe,
    TimeAgoPipe,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div>
      <header class="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 class="text-3xl font-extrabold text-ink mb-1">เอกสารของฉัน</h1>
          <p class="text-sm text-ink-soft">
            จัดการเอกสารทั้งหมดของร้าน — แก้ไข ลบ หรือดูสถิติได้จากที่นี่
          </p>
        </div>
        <a routerLink="/seller/upload" class="btn-pink">
          <app-icon name="plus" [size]="16" />
          อัปโหลดใหม่
        </a>
      </header>

      <!-- Filter bar -->
      <div class="card-soft p-4 mb-5 flex flex-col md:flex-row gap-3">
        <div class="relative flex-1">
          <span class="absolute left-4 top-1/2 -translate-y-1/2 text-ink-muted">
            <app-icon name="search" [size]="18" />
          </span>
          <input
            type="search"
            [(ngModel)]="search"
            placeholder="ค้นหาเอกสารในร้านของคุณ…"
            class="w-full pl-11 pr-4 py-2.5 rounded-2xl border border-line bg-white focus:border-pink-300 focus:outline-none focus:ring-4 focus:ring-pink-100 text-sm"
          />
        </div>
        <div class="flex gap-2">
          @for (s of statuses; track s.value) {
            <button
              class="px-4 py-2.5 rounded-2xl text-sm font-medium border transition-colors"
              [class.bg-pink-500]="status() === s.value"
              [class.text-white]="status() === s.value"
              [class.border-pink-500]="status() === s.value"
              [class.bg-white]="status() !== s.value"
              [class.text-ink-soft]="status() !== s.value"
              [class.border-line]="status() !== s.value"
              (click)="status.set(s.value)"
            >
              {{ s.label }}
            </button>
          }
        </div>
      </div>

      <!-- Doc table -->
      <div class="card-soft overflow-hidden">
        <table class="w-full">
          <thead class="bg-pink-50">
            <tr class="text-left text-xs uppercase tracking-wider text-ink-muted">
              <th class="px-5 py-3 font-semibold">เอกสาร</th>
              <th class="px-5 py-3 font-semibold">ราคา</th>
              <th class="px-5 py-3 font-semibold">ยอดขาย</th>
              <th class="px-5 py-3 font-semibold">คะแนน</th>
              <th class="px-5 py-3 font-semibold">สถานะ</th>
              <th class="px-5 py-3 font-semibold">อัปเดต</th>
              <th class="px-5 py-3"></th>
            </tr>
          </thead>
          <tbody>
            @for (d of filteredDocs(); track d.id) {
              <tr class="border-t border-line hover:bg-pink-50/40 transition-colors">
                <td class="px-5 py-4">
                  <div class="flex items-center gap-3">
                    <img [src]="d.cover" class="w-10 h-12 rounded-lg object-cover" alt="" />
                    <div class="min-w-0">
                      <div class="text-sm font-bold text-ink line-clamp-1">{{ d.title }}</div>
                      <div class="text-xs text-ink-muted uppercase">{{ d.format }} · {{ d.pages }} หน้า</div>
                    </div>
                  </div>
                </td>
                <td class="px-5 py-4 text-sm font-bold text-ink whitespace-nowrap">
                  {{ d.price | thb }}
                </td>
                <td class="px-5 py-4 text-sm text-ink whitespace-nowrap">
                  {{ d.downloads | compact }}
                </td>
                <td class="px-5 py-4 text-sm whitespace-nowrap">
                  <span class="text-pink-600 font-bold">★ {{ d.rating }}</span>
                  <span class="text-xs text-ink-muted ml-1">({{ d.reviewCount }})</span>
                </td>
                <td class="px-5 py-4">
                  <span class="pill-pink">เผยแพร่</span>
                </td>
                <td class="px-5 py-4 text-xs text-ink-muted whitespace-nowrap">
                  {{ d.updatedAt | timeAgo }}
                </td>
                <td class="px-5 py-4">
                  <div class="flex items-center gap-1 justify-end">
                    <button class="btn-icon !w-8 !h-8" title="ดู">
                      <app-icon name="eye" [size]="14" />
                    </button>
                    <button class="btn-icon !w-8 !h-8" title="แก้ไข">
                      <app-icon name="edit" [size]="14" />
                    </button>
                    <button
                      class="btn-icon !w-8 !h-8 hover:!bg-rose-50 hover:!text-rose-500 hover:!border-rose-200"
                      title="ลบ"
                      (click)="confirmRemove(d.id, d.title)"
                    >
                      <app-icon name="trash" [size]="14" />
                    </button>
                  </div>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
})
export class SellerDocumentsPage {
  readonly seller = inject(SellerService);
  private readonly message = inject(NzMessageService);

  readonly search = signal<string>('');
  readonly status = signal<'all' | 'approved' | 'pending'>('all');

  readonly statuses = [
    { value: 'all' as const, label: 'ทั้งหมด' },
    { value: 'approved' as const, label: 'เผยแพร่แล้ว' },
    { value: 'pending' as const, label: 'รออนุมัติ' },
  ];

  filteredDocs() {
    let docs = this.seller.myDocuments();
    if (this.status() !== 'all') {
      docs = docs.filter((d) => d.status === this.status());
    }
    if (this.search().trim()) {
      const q = this.search().toLowerCase();
      docs = docs.filter((d) => d.title.toLowerCase().includes(q));
    }
    return docs;
  }

  confirmRemove(id: string, title: string): void {
    this.seller.remove(id);
    this.message.success(`ลบ "${title}" เรียบร้อย`);
  }
}
