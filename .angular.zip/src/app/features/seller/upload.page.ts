import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { NzMessageService } from 'ng-zorro-antd/message';
import { CatalogService } from '../../core/services';
import { IconComponent } from '../../shared/components/icon.component';
import { ThbPipe } from '../../shared/pipes/thb.pipe';

@Component({
  selector: 'app-seller-upload',
  standalone: true,
  imports: [RouterLink, FormsModule, IconComponent, ThbPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-5xl">
      <header class="mb-8">
        <h1 class="text-3xl font-extrabold text-ink mb-1">อัปโหลดเอกสารใหม่</h1>
        <p class="text-sm text-ink-soft">
          ทำตาม 4 ขั้นตอนเพื่อเผยแพร่เอกสารของคุณบน SIRIEDUMARKET
        </p>
      </header>

      <!-- Steps -->
      <ol class="flex items-center justify-between mb-10 max-w-3xl">
        @for (s of steps; track s.no; let i = $index) {
          <li class="flex items-center" [class.flex-1]="i < 3">
            <button
              type="button"
              class="flex flex-col items-center gap-2 group"
              (click)="step.set(s.no)"
            >
              <span
                class="w-10 h-10 rounded-full text-sm font-bold flex items-center justify-center transition-all"
                [class]="
                  step() === s.no
                    ? 'bg-pink-500 text-white shadow-soft scale-110'
                    : step() > s.no
                      ? 'bg-pink-100 text-pink-600'
                      : 'bg-white border border-line text-ink-muted'
                "
              >
                @if (step() > s.no) {
                  <app-icon name="check" [size]="16" />
                } @else {
                  {{ s.no }}
                }
              </span>
              <span
                class="text-xs font-semibold transition-colors"
                [class.text-pink-600]="step() === s.no"
                [class.text-ink]="step() > s.no"
                [class.text-ink-muted]="step() < s.no"
              >
                {{ s.label }}
              </span>
            </button>
            @if (i < 3) {
              <span
                class="flex-1 h-1 mx-2 rounded-full transition-colors"
                [class.bg-pink-300]="step() > s.no"
                [class.bg-line]="step() <= s.no"
              ></span>
            }
          </li>
        }
      </ol>

      <div class="grid lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2">
          <!-- Step 1: File -->
          @if (step() === 1) {
            <section class="card-soft p-6">
              <h2 class="text-lg font-bold text-ink mb-1">อัปโหลดไฟล์</h2>
              <p class="text-sm text-ink-muted mb-6">
                รองรับ PDF, DOCX, PPTX, XLSX, ZIP — ขนาดสูงสุด 200MB
              </p>

              @if (!file()) {
                <label
                  class="block border-2 border-dashed border-pink-200 rounded-3xl p-10 text-center cursor-pointer hover:border-pink-300 hover:bg-pink-50/40 transition-all"
                >
                  <input type="file" class="hidden" (change)="onFile($event)" />
                  <div
                    class="w-16 h-16 rounded-2xl bg-pink-100 text-pink-600 flex items-center justify-center mx-auto mb-4"
                  >
                    <app-icon name="upload" [size]="28" />
                  </div>
                  <h3 class="text-base font-bold text-ink mb-1">ลากไฟล์มาวาง หรือคลิกเพื่อเลือก</h3>
                  <p class="text-xs text-ink-muted">อัปโหลดได้ทีละ 1 ไฟล์</p>

                  <div class="flex flex-wrap items-center justify-center gap-2 mt-5">
                    @for (f of formats; track f) {
                      <span class="pill-soft uppercase">{{ f }}</span>
                    }
                  </div>
                </label>
              } @else {
                <div class="border border-pink-200 rounded-3xl p-6 bg-pink-50">
                  <div class="flex items-center gap-4">
                    <div class="w-16 h-20 rounded-2xl bg-white flex items-center justify-center text-pink-500">
                      <app-icon name="doc" [size]="28" />
                    </div>
                    <div class="flex-1 min-w-0">
                      <div class="text-sm font-bold text-ink truncate">{{ file()!.name }}</div>
                      <div class="text-xs text-ink-muted">
                        {{ (file()!.size / 1024 / 1024).toFixed(2) }} MB
                      </div>
                      <div class="mt-3 h-1.5 rounded-full bg-pink-100 overflow-hidden">
                        <div class="h-full bg-pink-500 rounded-full" style="width: 100%"></div>
                      </div>
                      <div class="text-xs text-emerald-600 font-bold mt-1.5">
                        <app-icon name="check" [size]="11" />
                        อัปโหลดเรียบร้อย
                      </div>
                    </div>
                    <button class="btn-icon" (click)="file.set(null)">
                      <app-icon name="trash" [size]="16" />
                    </button>
                  </div>
                </div>
              }

              <!-- Watermark + preview options -->
              <div class="grid sm:grid-cols-2 gap-3 mt-6">
                <label class="flex items-start gap-3 p-4 rounded-2xl border border-line cursor-pointer hover:border-pink-300">
                  <input type="checkbox" [(ngModel)]="watermark" class="w-5 h-5 accent-pink-500 mt-0.5" />
                  <div>
                    <div class="text-sm font-semibold text-ink flex items-center gap-1.5">
                      <app-icon name="shield" [size]="14" className="text-pink-500" />
                      เปิดใช้ลายน้ำ
                    </div>
                    <div class="text-xs text-ink-muted mt-1">
                      เพิ่ม Watermark ของผู้ซื้อในทุกหน้าของไฟล์
                    </div>
                  </div>
                </label>
                <label class="flex items-start gap-3 p-4 rounded-2xl border border-line cursor-pointer hover:border-pink-300">
                  <input type="number" [(ngModel)]="previewPages" min="0" class="w-14 input-soft !py-1.5 !px-2 text-center font-bold" />
                  <div>
                    <div class="text-sm font-semibold text-ink">หน้าพรีวิวฟรี</div>
                    <div class="text-xs text-ink-muted mt-1">
                      จำนวนหน้าที่ผู้ซื้อดูได้ก่อนตัดสินใจซื้อ
                    </div>
                  </div>
                </label>
              </div>

              <div class="flex justify-end mt-8">
                <button class="btn-pink" (click)="next()" [disabled]="!file()">
                  ถัดไป
                  <app-icon name="arrow-right" [size]="16" />
                </button>
              </div>
            </section>
          }

          <!-- Step 2: Detail -->
          @if (step() === 2) {
            <section class="card-soft p-6">
              <h2 class="text-lg font-bold text-ink mb-1">รายละเอียดเอกสาร</h2>
              <p class="text-sm text-ink-muted mb-6">
                ใส่ข้อมูลให้ครบเพื่อเพิ่มโอกาสในการขาย
              </p>

              <div class="space-y-5">
                <div>
                  <label class="text-xs font-semibold text-ink-soft mb-2 flex items-center justify-between">
                    <span>ชื่อเอกสาร <span class="text-pink-500">*</span></span>
                    <span class="text-ink-muted">{{ title().length }}/80</span>
                  </label>
                  <input
                    [(ngModel)]="title"
                    class="input-soft"
                    placeholder="เช่น: สรุปคณิตม.ปลาย ครบ 6 บท ฉบับติวเข้ม"
                    maxlength="80"
                  />
                </div>

                <div>
                  <label class="text-xs font-semibold text-ink-soft mb-2 flex items-center justify-between">
                    <span>คำอธิบายสั้น</span>
                    <button
                      class="pill-pink !text-[10px] hover:!bg-pink-200"
                      (click)="aiSuggest('short')"
                    >
                      <app-icon name="sparkle" [size]="11" />
                      AI ช่วยเขียน
                    </button>
                  </label>
                  <input
                    [(ngModel)]="shortDescription"
                    class="input-soft"
                    placeholder="ประโยคที่จะแสดงในการ์ดเอกสาร"
                  />
                </div>

                <div>
                  <label class="text-xs font-semibold text-ink-soft mb-2 flex items-center justify-between">
                    <span>คำอธิบายเต็ม</span>
                    <button
                      class="pill-pink !text-[10px] hover:!bg-pink-200"
                      (click)="aiSuggest('long')"
                    >
                      <app-icon name="sparkle" [size]="11" />
                      AI ขยายเนื้อหา
                    </button>
                  </label>
                  <textarea
                    [(ngModel)]="longDescription"
                    rows="6"
                    class="input-soft"
                    placeholder="อธิบายเนื้อหา ผู้เรียนจะได้อะไรจากเอกสารนี้ บอกจุดเด่นที่ทำให้คนซื้อ"
                  ></textarea>
                </div>

                <div class="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label class="text-xs font-semibold text-ink-soft mb-2 block">
                      หมวดหมู่ <span class="text-pink-500">*</span>
                    </label>
                    <select [(ngModel)]="categoryId" class="input-soft cursor-pointer">
                      <option [ngValue]="''">เลือกหมวดหมู่...</option>
                      @for (c of catalog.categories(); track c.id) {
                        <option [ngValue]="c.id">{{ c.icon }} {{ c.name }}</option>
                      }
                    </select>
                  </div>
                  <div>
                    <label class="text-xs font-semibold text-ink-soft mb-2 block">
                      ภาษา
                    </label>
                    <select [(ngModel)]="language" class="input-soft cursor-pointer">
                      <option value="th">ภาษาไทย</option>
                      <option value="en">ภาษาอังกฤษ</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label class="text-xs font-semibold text-ink-soft mb-2 block">
                    แท็ก
                  </label>
                  <div class="flex flex-wrap gap-2 p-3 rounded-2xl border border-line bg-white">
                    @for (t of tags(); track t) {
                      <span class="pill-pink gap-1.5 cursor-pointer" (click)="removeTag(t)">
                        #{{ t }}
                        <app-icon name="x" [size]="11" />
                      </span>
                    }
                    <input
                      type="text"
                      [(ngModel)]="newTag"
                      (keydown.enter)="addTag(); $event.preventDefault()"
                      class="flex-1 min-w-[120px] outline-none text-sm bg-transparent"
                      placeholder="พิมพ์แท็กแล้วกด Enter"
                    />
                  </div>
                </div>
              </div>

              <div class="flex justify-between mt-8">
                <button class="btn-ghost" (click)="prev()">
                  <app-icon name="arrow-left" [size]="16" />
                  ย้อนกลับ
                </button>
                <button class="btn-pink" (click)="next()">
                  ถัดไป
                  <app-icon name="arrow-right" [size]="16" />
                </button>
              </div>
            </section>
          }

          <!-- Step 3: Pricing -->
          @if (step() === 3) {
            <section class="card-soft p-6">
              <h2 class="text-lg font-bold text-ink mb-1">ตั้งราคา</h2>
              <p class="text-sm text-ink-muted mb-6">
                เลือกราคาที่เหมาะกับเนื้อหา — เราเก็บค่าธรรมเนียม 10% ที่เหลือเป็นของคุณ
              </p>

              <div class="grid sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label class="text-xs font-semibold text-ink-soft mb-2 block">ราคา (THB)</label>
                  <div class="relative">
                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-ink-muted font-bold">฿</span>
                    <input [(ngModel)]="price" type="number" min="0" step="10" class="input-soft !pl-9" />
                  </div>
                </div>
                <div>
                  <label class="text-xs font-semibold text-ink-soft mb-2 block">ราคาเดิม (option)</label>
                  <div class="relative">
                    <span class="absolute left-4 top-1/2 -translate-y-1/2 text-ink-muted font-bold">฿</span>
                    <input [(ngModel)]="originalPrice" type="number" min="0" step="10" class="input-soft !pl-9" placeholder="0" />
                  </div>
                </div>
              </div>

              <!-- Suggestion chips -->
              <div class="mb-6">
                <div class="text-xs text-ink-muted mb-2">ราคายอดนิยมในหมวดเดียวกัน</div>
                <div class="flex flex-wrap gap-2">
                  @for (p of [99, 199, 299, 399, 499, 690]; track p) {
                    <button class="pill-soft hover:!border-pink-300 hover:!text-pink-600" (click)="price.set(p)">
                      ฿{{ p }}
                    </button>
                  }
                </div>
              </div>

              <!-- Earnings card -->
              <div class="p-5 rounded-3xl bg-gradient-pink border border-line">
                <div class="text-xs text-ink-muted mb-1">คุณจะได้รับต่อยอดขาย 1 ครั้ง</div>
                <div class="text-3xl font-extrabold text-pink-700">
                  {{ earnings() | thb }}
                </div>
                <div class="text-xs text-ink-muted mt-2">
                  หักค่าธรรมเนียมแพลตฟอร์ม {{ fee() | thb }} (10%)
                </div>
              </div>

              <div class="flex justify-between mt-8">
                <button class="btn-ghost" (click)="prev()">
                  <app-icon name="arrow-left" [size]="16" />
                  ย้อนกลับ
                </button>
                <button class="btn-pink" (click)="next()">
                  ถัดไป
                  <app-icon name="arrow-right" [size]="16" />
                </button>
              </div>
            </section>
          }

          <!-- Step 4: Review -->
          @if (step() === 4) {
            <section class="card-soft p-6">
              <h2 class="text-lg font-bold text-ink mb-1">ตรวจสอบและส่งเข้าพิจารณา</h2>
              <p class="text-sm text-ink-muted mb-6">
                ทีมงานจะตรวจสอบและอนุมัติภายใน 24 ชั่วโมง
              </p>

              <ul class="divide-y divide-line">
                <li class="py-3 flex justify-between text-sm">
                  <span class="text-ink-muted">ชื่อเอกสาร</span>
                  <span class="text-ink font-semibold text-right max-w-xs line-clamp-2">
                    {{ title() || '—' }}
                  </span>
                </li>
                <li class="py-3 flex justify-between text-sm">
                  <span class="text-ink-muted">หมวดหมู่</span>
                  <span class="text-ink font-semibold">
                    {{ categoryLabel() }}
                  </span>
                </li>
                <li class="py-3 flex justify-between text-sm">
                  <span class="text-ink-muted">ราคา</span>
                  <span class="text-ink font-semibold">{{ price() | thb }}</span>
                </li>
                <li class="py-3 flex justify-between text-sm">
                  <span class="text-ink-muted">รายได้ต่อชิ้น</span>
                  <span class="text-pink-600 font-bold">{{ earnings() | thb }}</span>
                </li>
                <li class="py-3 flex justify-between text-sm">
                  <span class="text-ink-muted">ลายน้ำ</span>
                  <span class="text-ink font-semibold">
                    {{ watermark() ? 'เปิดใช้' : 'ปิด' }}
                  </span>
                </li>
                <li class="py-3 flex justify-between text-sm">
                  <span class="text-ink-muted">หน้าพรีวิว</span>
                  <span class="text-ink font-semibold">{{ previewPages() }} หน้า</span>
                </li>
              </ul>

              <div class="flex justify-between mt-8">
                <button class="btn-ghost" (click)="prev()">
                  <app-icon name="arrow-left" [size]="16" />
                  ย้อนกลับ
                </button>
                <button class="btn-pink !px-7" (click)="submit()">
                  <app-icon name="check" [size]="16" />
                  ส่งเข้าพิจารณา
                </button>
              </div>
            </section>
          }
        </div>

        <!-- Right tip -->
        <aside class="lg:col-span-1">
          <div class="card-soft p-5 sticky top-6">
            <h3 class="text-sm font-bold text-ink mb-3 flex items-center gap-2">
              <app-icon name="sparkle" [size]="16" className="text-pink-500" />
              เคล็ดลับการขาย
            </h3>
            <ul class="space-y-3 text-sm">
              <li class="flex gap-3">
                <span class="w-6 h-6 rounded-lg bg-pink-100 text-pink-600 flex items-center justify-center text-xs font-bold flex-shrink-0">1</span>
                <span class="text-ink-soft">ตั้งชื่อให้เห็นภาพและเฉพาะเจาะจง เช่น "สรุปคณิตม.6 ฉบับติวเข้ม 80 หน้า"</span>
              </li>
              <li class="flex gap-3">
                <span class="w-6 h-6 rounded-lg bg-pink-100 text-pink-600 flex items-center justify-center text-xs font-bold flex-shrink-0">2</span>
                <span class="text-ink-soft">ใช้ AI ช่วยสรุป/เขียนคำอธิบาย เพิ่มโอกาสคนกดเข้ามาดู</span>
              </li>
              <li class="flex gap-3">
                <span class="w-6 h-6 rounded-lg bg-pink-100 text-pink-600 flex items-center justify-center text-xs font-bold flex-shrink-0">3</span>
                <span class="text-ink-soft">เปิดพรีวิว 5-10% ของเล่ม ช่วยให้ผู้ซื้อตัดสินใจได้เร็ว</span>
              </li>
              <li class="flex gap-3">
                <span class="w-6 h-6 rounded-lg bg-pink-100 text-pink-600 flex items-center justify-center text-xs font-bold flex-shrink-0">4</span>
                <span class="text-ink-soft">ตั้งราคาเริ่มต้นต่ำกว่าค่าเฉลี่ย ดึง early reviews มาช่วยขาย</span>
              </li>
            </ul>

            <div class="mt-5 pt-5 border-t border-line">
              <a routerLink="/seller/ai" class="btn-ghost w-full !py-2.5 text-sm">
                <app-icon name="sparkle" [size]="14" />
                ลองใช้ AI Assistant
              </a>
            </div>
          </div>
        </aside>
      </div>
    </div>
  `,
})
export class SellerUploadPage {
  readonly catalog = inject(CatalogService);
  private readonly message = inject(NzMessageService);
  private readonly router = inject(Router);

  readonly steps = [
    { no: 1, label: 'อัปโหลด' },
    { no: 2, label: 'รายละเอียด' },
    { no: 3, label: 'ตั้งราคา' },
    { no: 4, label: 'ตรวจสอบ' },
  ];

  readonly formats = ['PDF', 'DOCX', 'PPTX', 'XLSX', 'ZIP'];

  readonly step = signal<number>(1);
  readonly file = signal<File | null>(null);
  readonly watermark = signal<boolean>(true);
  readonly previewPages = signal<number>(5);

  readonly title = signal<string>('');
  readonly shortDescription = signal<string>('');
  readonly longDescription = signal<string>('');
  readonly categoryId = signal<string>('');
  readonly language = signal<'th' | 'en'>('th');
  readonly tags = signal<string[]>([]);
  readonly newTag = signal<string>('');

  readonly price = signal<number>(199);
  readonly originalPrice = signal<number>(0);

  readonly categoryLabel = computed(() => {
    const c = this.catalog.getCategoryById(this.categoryId());
    return c ? `${c.icon} ${c.name}` : '—';
  });

  readonly fee = computed(() => Math.round(this.price() * 0.1));
  readonly earnings = computed(() => this.price() - this.fee());

  onFile(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files?.length) {
      this.file.set(input.files[0]);
      this.message.success('อัปโหลดไฟล์สำเร็จ');
    }
  }

  next(): void {
    this.step.update((s) => Math.min(4, s + 1));
  }
  prev(): void {
    this.step.update((s) => Math.max(1, s - 1));
  }

  addTag(): void {
    const t = this.newTag().trim();
    if (t && !this.tags().includes(t)) {
      this.tags.update((list) => [...list, t]);
    }
    this.newTag.set('');
  }
  removeTag(t: string): void {
    this.tags.update((list) => list.filter((x) => x !== t));
  }

  aiSuggest(kind: 'short' | 'long'): void {
    if (kind === 'short') {
      this.shortDescription.set(
        'สรุปเนื้อหาคุณภาพ ใช้ทบทวนได้ทันที พร้อมตัวอย่างแบบฝึกหัด',
      );
    } else {
      this.longDescription.set(
        'เอกสารฉบับนี้รวบรวมเนื้อหาที่จำเป็นและคัดเฉพาะส่วนที่ออกสอบบ่อยที่สุด พร้อมตัวอย่างประกอบและแบบฝึกหัด ช่วยให้ผู้อ่านเข้าใจเนื้อหาในเวลาอันรวดเร็ว เหมาะสำหรับนักเรียนและผู้ที่เตรียมสอบทุกระดับชั้น',
      );
    }
    this.message.success('AI ช่วยเขียนเสร็จแล้ว ลองปรับให้เป็นสไตล์คุณดูครับ');
  }

  submit(): void {
    this.message.success('ส่งเข้าพิจารณาเรียบร้อย — ทีมงานจะตอบกลับภายใน 24 ชม.');
    this.router.navigate(['/seller/documents']);
  }
}
