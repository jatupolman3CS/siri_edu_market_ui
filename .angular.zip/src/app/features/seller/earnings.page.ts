import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { SellerService } from '../../core/services';
import { StatCardComponent } from '../../shared/components/stat-card.component';
import { IconComponent } from '../../shared/components/icon.component';
import { ThbPipe } from '../../shared/pipes/thb.pipe';

@Component({
  selector: 'app-seller-earnings',
  standalone: true,
  imports: [StatCardComponent, IconComponent, ThbPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-5xl">
      <header class="mb-8">
        <h1 class="text-3xl font-extrabold text-ink mb-1">รายได้ & Payout</h1>
        <p class="text-sm text-ink-soft">
          ดูรายได้ ค่าธรรมเนียม และประวัติการถอนเงิน
        </p>
      </header>

      <section class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <app-stat-card
          label="รายได้รวม"
          [value]="seller.stats().totalRevenue | thb"
          icon="💰"
        />
        <app-stat-card
          label="รอจ่าย"
          [value]="seller.stats().pendingPayout | thb"
          icon="⏳"
        />
        <app-stat-card
          label="เดือนนี้"
          [value]="seller.stats().monthlyRevenue | thb"
          icon="📅"
          trend="+18%"
        />
        <app-stat-card
          label="ส่วนแบ่งของคุณ"
          value="90%"
          icon="🌸"
        />
      </section>

      <div class="card-soft p-6 mb-6 bg-gradient-pink">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div>
            <div class="text-xs text-ink-muted mb-1">เงินรอจ่ายในรอบถัดไป</div>
            <div class="text-4xl md:text-5xl font-extrabold text-pink-700">
              {{ seller.stats().pendingPayout | thb }}
            </div>
            <div class="text-sm text-ink-soft mt-2">
              โอนรอบถัดไป: <b>15 พ.ค. 2026</b> — เข้าบัญชี กสิกรไทย ****-1234
            </div>
          </div>
          <button class="btn-pink !px-7 !py-3.5">
            <app-icon name="wallet" [size]="18" />
            ขอถอนเงินทันที
          </button>
        </div>
      </div>

      <!-- Recent payout history -->
      <section class="card-soft p-6">
        <h2 class="text-lg font-bold text-ink mb-1">ประวัติการถอน</h2>
        <p class="text-xs text-ink-muted mb-5">รายการการโอนเงินเข้าบัญชีของคุณ</p>
        <table class="w-full">
          <thead class="bg-pink-50">
            <tr class="text-left text-xs uppercase tracking-wider text-ink-muted">
              <th class="px-5 py-3 font-semibold">วันที่</th>
              <th class="px-5 py-3 font-semibold">ยอดที่ถอน</th>
              <th class="px-5 py-3 font-semibold">ค่าธรรมเนียม</th>
              <th class="px-5 py-3 font-semibold">สถานะ</th>
              <th class="px-5 py-3 font-semibold">บัญชี</th>
            </tr>
          </thead>
          <tbody>
            @for (p of payouts; track p.id) {
              <tr class="border-t border-line">
                <td class="px-5 py-3 text-sm text-ink whitespace-nowrap">{{ p.date }}</td>
                <td class="px-5 py-3 text-sm text-ink font-bold whitespace-nowrap">{{ p.amount | thb }}</td>
                <td class="px-5 py-3 text-sm text-ink-muted whitespace-nowrap">{{ p.fee | thb }}</td>
                <td class="px-5 py-3 whitespace-nowrap">
                  @if (p.status === 'paid') {
                    <span class="pill bg-emerald-100 text-emerald-700">โอนเรียบร้อย</span>
                  } @else {
                    <span class="pill bg-amber-100 text-amber-700">กำลังดำเนินการ</span>
                  }
                </td>
                <td class="px-5 py-3 text-sm text-ink-soft whitespace-nowrap">{{ p.account }}</td>
              </tr>
            }
          </tbody>
        </table>
      </section>
    </div>
  `,
})
export class SellerEarningsPage {
  readonly seller = inject(SellerService);

  readonly payouts = [
    { id: 1, date: '15 เม.ย. 2026', amount: 32400, fee: 0, status: 'paid', account: 'KBANK ****1234' },
    { id: 2, date: '15 มี.ค. 2026', amount: 28100, fee: 0, status: 'paid', account: 'KBANK ****1234' },
    { id: 3, date: '15 ก.พ. 2026', amount: 26800, fee: 0, status: 'paid', account: 'KBANK ****1234' },
    { id: 4, date: '15 ม.ค. 2026', amount: 22400, fee: 0, status: 'paid', account: 'KBANK ****1234' },
  ];
}
