import { ChangeDetectionStrategy, Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IconComponent } from '../../shared/components/icon.component';

@Component({
  selector: 'app-seller-settings',
  standalone: true,
  imports: [FormsModule, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-3xl">
      <header class="mb-8">
        <h1 class="text-3xl font-extrabold text-ink mb-1">ตั้งค่าร้าน</h1>
        <p class="text-sm text-ink-soft">
          ปรับแต่งโปรไฟล์ร้านและข้อมูลการชำระเงินของคุณ
        </p>
      </header>

      <!-- Profile -->
      <section class="card-soft p-6 mb-6">
        <h2 class="text-lg font-bold text-ink mb-1">โปรไฟล์ร้าน</h2>
        <p class="text-xs text-ink-muted mb-5">ข้อมูลที่ผู้ซื้อจะเห็นในหน้าร้านของคุณ</p>

        <div class="flex items-center gap-5 mb-6">
          <img
            src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=face"
            class="w-20 h-20 rounded-3xl object-cover ring-2 ring-pink-100"
            alt="avatar"
          />
          <div>
            <button class="btn-ghost text-sm">
              <app-icon name="upload" [size]="14" />
              เปลี่ยนรูป
            </button>
            <div class="text-xs text-ink-muted mt-2">JPG/PNG · ไม่เกิน 2MB</div>
          </div>
        </div>

        <div class="grid sm:grid-cols-2 gap-4">
          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">ชื่อร้าน</label>
            <input class="input-soft" value="Siri Studio" />
          </div>
          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">ชื่อเจ้าของ</label>
            <input class="input-soft" value="ศิริพร วงศ์สวรรค์" />
          </div>
          <div class="sm:col-span-2">
            <label class="text-xs font-semibold text-ink-soft mb-2 block">เกี่ยวกับร้าน</label>
            <textarea rows="3" class="input-soft">ติวเตอร์คณิตศาสตร์ระดับมัธยม ประสบการณ์ 8 ปี เน้นสรุปกระชับ จำง่าย เข้าสอบได้</textarea>
          </div>
        </div>
      </section>

      <!-- Bank info -->
      <section class="card-soft p-6 mb-6">
        <h2 class="text-lg font-bold text-ink mb-1">บัญชีรับเงิน</h2>
        <p class="text-xs text-ink-muted mb-5">เราจะโอนรายได้ของคุณเข้าบัญชีนี้ทุกวันที่ 15</p>

        <div class="grid sm:grid-cols-2 gap-4">
          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">ธนาคาร</label>
            <select class="input-soft cursor-pointer">
              <option>กสิกรไทย (KBANK)</option>
              <option>ไทยพาณิชย์ (SCB)</option>
              <option>กรุงเทพ (BBL)</option>
              <option>กรุงไทย (KTB)</option>
              <option>กรุงศรี (BAY)</option>
            </select>
          </div>
          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">เลขบัญชี</label>
            <input class="input-soft" value="123-4-56789-0" />
          </div>
          <div class="sm:col-span-2">
            <label class="text-xs font-semibold text-ink-soft mb-2 block">ชื่อบัญชี</label>
            <input class="input-soft" value="นางสาว ศิริพร วงศ์สวรรค์" />
          </div>
        </div>
      </section>

      <!-- Notification -->
      <section class="card-soft p-6 mb-6">
        <h2 class="text-lg font-bold text-ink mb-1">การแจ้งเตือน</h2>
        <p class="text-xs text-ink-muted mb-5">เลือกอีเวนต์ที่คุณอยากรับแจ้งเตือน</p>

        <div class="space-y-3">
          @for (n of notifications; track n.key) {
            <label class="flex items-start gap-3 p-3 rounded-2xl border border-line cursor-pointer hover:border-pink-300">
              <input
                type="checkbox"
                [checked]="n.checked"
                class="w-5 h-5 accent-pink-500 mt-0.5"
              />
              <div>
                <div class="text-sm font-semibold text-ink">{{ n.label }}</div>
                <div class="text-xs text-ink-muted mt-0.5">{{ n.note }}</div>
              </div>
            </label>
          }
        </div>
      </section>

      <div class="flex gap-3 justify-end">
        <button class="btn-ghost">ยกเลิก</button>
        <button class="btn-pink !px-7">
          <app-icon name="check" [size]="16" />
          บันทึกการเปลี่ยนแปลง
        </button>
      </div>
    </div>
  `,
})
export class SellerSettingsPage {
  readonly notifications = [
    { key: 'sale', label: 'มียอดขายใหม่', note: 'แจ้งเตือนเมื่อมีคนซื้อเอกสารของคุณ', checked: true },
    { key: 'review', label: 'มีรีวิวใหม่', note: 'รีวิวจากผู้ที่ซื้อแล้ว', checked: true },
    { key: 'payout', label: 'รายได้พร้อมโอน', note: 'เมื่อยอดถึงระดับที่กำหนด', checked: true },
    { key: 'tips', label: 'เคล็ดลับการขาย', note: 'ทิปและข่าวสารจาก SIRIEDUMARKET', checked: false },
  ];
}
