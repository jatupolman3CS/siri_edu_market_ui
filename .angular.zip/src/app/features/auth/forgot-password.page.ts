import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/services';
import { AuthLayoutComponent } from '../../layouts/auth/auth-layout.component';
import { IconComponent } from '../../shared/components/icon.component';

@Component({
  selector: 'app-auth-forgot-password',
  standalone: true,
  imports: [RouterLink, FormsModule, AuthLayoutComponent, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <app-auth-layout
      artTitle="ลืมรหัสผ่าน?<br>ไม่เป็นไรครับ 🌷"
      artDescription="กรอกอีเมลที่ใช้สมัคร เราจะส่งลิงก์รีเซ็ตรหัสผ่านให้"
    >
      <div class="max-w-md w-full mx-auto">
        @if (!sent()) {
          <h1 class="text-3xl font-extrabold text-ink mb-2 leading-tight">
            รีเซ็ตรหัสผ่าน
          </h1>
          <p class="text-sm text-ink-soft mb-8">
            กรอกอีเมลของคุณ เราจะส่งลิงก์ตั้งรหัสผ่านใหม่ให้
          </p>

          <form (ngSubmit)="onSubmit()" class="space-y-5">
            <div>
              <label class="text-xs font-semibold text-ink-soft mb-2 block">อีเมล</label>
              <div class="relative">
                <span class="absolute left-4 top-1/2 -translate-y-1/2 text-ink-muted">
                  <app-icon name="mail" [size]="18" />
                </span>
                <input
                  type="email"
                  [(ngModel)]="email"
                  name="email"
                  class="input-soft !pl-12"
                  placeholder="you@example.com"
                  required
                />
              </div>
            </div>

            @if (error()) {
              <div class="px-4 py-2.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 text-sm">
                {{ error() }}
              </div>
            }

            <button type="submit" class="btn-pink w-full !py-3.5">
              <app-icon name="mail" [size]="16" />
              ส่งลิงก์รีเซ็ต
            </button>
          </form>

          <p class="text-sm text-ink-muted text-center mt-6">
            <a routerLink="/auth/login" class="text-pink-600 font-bold hover:underline">
              ← กลับไปเข้าสู่ระบบ
            </a>
          </p>
        } @else {
          <div class="text-center">
            <div class="w-20 h-20 mx-auto rounded-3xl bg-emerald-100 text-emerald-600 flex items-center justify-center text-4xl mb-5">
              📨
            </div>
            <h1 class="text-2xl font-extrabold text-ink mb-2">เช็คอีเมลของคุณ</h1>
            <p class="text-sm text-ink-soft mb-6 max-w-sm mx-auto">
              เราส่งลิงก์รีเซ็ตรหัสผ่านไปยัง <b class="text-ink">{{ email() }}</b> แล้ว
              กรุณาเช็คในกล่องจดหมายและกล่อง spam ด้วย
            </p>
            <div class="flex flex-col gap-3 max-w-xs mx-auto">
              <a routerLink="/auth/login" class="btn-pink">กลับไปเข้าสู่ระบบ</a>
              <button class="btn-ghost" (click)="onSubmit()">ส่งซ้ำ</button>
            </div>
          </div>
        }
      </div>
    </app-auth-layout>
  `,
})
export class AuthForgotPasswordPage {
  private readonly auth = inject(AuthService);

  readonly email = signal<string>('');
  readonly sent = signal<boolean>(false);
  readonly error = signal<string>('');

  onSubmit(): void {
    this.error.set('');
    const r = this.auth.requestPasswordReset(this.email());
    if (!r.ok) {
      this.error.set(r.error ?? 'ส่งไม่สำเร็จ');
      return;
    }
    this.sent.set(true);
  }
}
