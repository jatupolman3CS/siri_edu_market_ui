import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AuthProvider, AuthService } from '../../core/services';
import { AuthLayoutComponent } from '../../layouts/auth/auth-layout.component';
import { SocialButtonsComponent } from '../../shared/components/social-buttons.component';
import { IconComponent } from '../../shared/components/icon.component';

@Component({
  selector: 'app-auth-register',
  standalone: true,
  imports: [
    RouterLink,
    FormsModule,
    AuthLayoutComponent,
    SocialButtonsComponent,
    IconComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <app-auth-layout
      artTitle="สมัครฟรี<br>เริ่มต้นชีวิตใหม่ 🌸"
      artDescription="สมัครครั้งเดียวใช้ได้ตลอด — ดาวน์โหลดเอกสารฟรี ติดตามครีเอเตอร์ และเปิดร้านของคุณเองได้"
      [artBullets]="[
        { icon: '🎁', label: 'รับเอกสารฟรีต้อนรับสมาชิกใหม่' },
        { icon: '💗', label: 'ติดตามครีเอเตอร์โปรดและไม่พลาดเอกสารใหม่' },
        { icon: '📦', label: 'ส่วนลดพิเศษสำหรับ Bundle ครั้งแรก' },
        { icon: '🛡️', label: 'บัญชีปลอดภัยด้วยการยืนยันอีเมล' },
      ]"
    >
      <div class="max-w-md w-full mx-auto">
        <span class="pill-pink mb-4">
          <span class="w-1.5 h-1.5 rounded-full bg-pink-500"></span>
          สมาชิกใหม่
        </span>
        <h1 class="text-3xl font-extrabold text-ink mb-2 leading-tight">
          สมัครสมาชิกฟรี
        </h1>
        <p class="text-sm text-ink-soft mb-8">
          มีบัญชีอยู่แล้ว?
          <a
            [routerLink]="['/auth/login']"
            [queryParams]="{ returnUrl: returnUrl() }"
            class="text-pink-600 font-bold hover:underline"
          >
            เข้าสู่ระบบ →
          </a>
        </p>

        <app-social-buttons (select)="onSocial($event)" />

        <div class="my-6 flex items-center gap-3 text-xs text-ink-muted">
          <span class="flex-1 h-px bg-line"></span>
          หรือสมัครด้วยอีเมล
          <span class="flex-1 h-px bg-line"></span>
        </div>

        <form (ngSubmit)="onSubmit()" class="space-y-4">
          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">ชื่อ-นามสกุล</label>
            <div class="relative">
              <span class="absolute left-4 top-1/2 -translate-y-1/2 text-ink-muted">
                <app-icon name="user" [size]="18" />
              </span>
              <input
                type="text"
                [(ngModel)]="name"
                name="name"
                class="input-soft !pl-12"
                placeholder="พิชญา ภัทราวดี"
                autocomplete="name"
                required
              />
            </div>
          </div>

          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">อีเมล</label>
            <div class="relative">
              <span class="absolute left-4 top-1/2 -translate-y-1/2 text-ink-muted">
                <app-icon name="mail" [size]="18" />
              </span>
              <input
                type="email"
                [(ngModel)]="email"
                name="email"
                class="input-soft !pl-12"
                placeholder="you@example.com"
                autocomplete="email"
                required
              />
            </div>
          </div>

          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">
              รหัสผ่าน <span class="text-ink-muted">(อย่างน้อย 6 ตัว)</span>
            </label>
            <div class="relative">
              <span class="absolute left-4 top-1/2 -translate-y-1/2 text-ink-muted">
                <app-icon name="lock" [size]="18" />
              </span>
              <input
                [type]="showPassword() ? 'text' : 'password'"
                [(ngModel)]="password"
                name="password"
                class="input-soft !pl-12 !pr-12"
                placeholder="•••••••••"
                autocomplete="new-password"
                required
              />
              <button
                type="button"
                class="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-ink-muted hover:text-pink-600"
                (click)="showPassword.set(!showPassword())"
              >
                <app-icon [name]="showPassword() ? 'eye' : 'lock'" [size]="16" />
              </button>
            </div>

            <!-- Strength meter -->
            @if (password().length > 0) {
              <div class="flex gap-1 mt-2">
                @for (i of [1, 2, 3, 4]; track i) {
                  <div
                    class="flex-1 h-1 rounded-full transition-colors"
                    [class.bg-pink-500]="strengthLevel() >= i"
                    [class.bg-pink-100]="strengthLevel() < i"
                  ></div>
                }
              </div>
              <div class="text-[11px] mt-1.5" [class]="strengthColor()">
                {{ strengthLabel() }}
              </div>
            }
          </div>

          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">ยืนยันรหัสผ่าน</label>
            <div class="relative">
              <span class="absolute left-4 top-1/2 -translate-y-1/2 text-ink-muted">
                <app-icon name="lock" [size]="18" />
              </span>
              <input
                [type]="showPassword() ? 'text' : 'password'"
                [(ngModel)]="confirmPassword"
                name="confirmPassword"
                class="input-soft !pl-12"
                placeholder="พิมพ์รหัสผ่านอีกครั้ง"
                autocomplete="new-password"
                required
              />
            </div>
          </div>

          <label class="flex items-start gap-2 text-sm text-ink-soft cursor-pointer">
            <input
              type="checkbox"
              [(ngModel)]="acceptTerms"
              name="acceptTerms"
              class="w-4 h-4 accent-pink-500 mt-0.5"
            />
            <span>
              ยอมรับ
              <a href="#" class="text-pink-600 hover:underline">เงื่อนไขการใช้งาน</a>
              และ
              <a href="#" class="text-pink-600 hover:underline">นโยบายความเป็นส่วนตัว</a>
            </span>
          </label>

          @if (error()) {
            <div class="px-4 py-2.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 text-sm flex items-center gap-2">
              <app-icon name="flag" [size]="14" />
              {{ error() }}
            </div>
          }

          <button
            type="submit"
            class="btn-pink w-full !py-3.5 mt-2 text-base"
            [disabled]="loading()"
          >
            @if (loading()) {
              <span class="inline-block animate-spin">✦</span>
              กำลังสร้างบัญชี…
            } @else {
              สมัครสมาชิก
              <app-icon name="arrow-right" [size]="16" />
            }
          </button>
        </form>

        <p class="text-[11px] text-ink-muted text-center mt-5">
          🛡️ ข้อมูลของคุณถูกเข้ารหัสและเก็บเป็นความลับตามนโยบาย PDPA
        </p>
      </div>
    </app-auth-layout>
  `,
})
export class AuthRegisterPage {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);

  readonly name = signal<string>('');
  readonly email = signal<string>('');
  readonly password = signal<string>('');
  readonly confirmPassword = signal<string>('');
  readonly acceptTerms = signal<boolean>(false);
  readonly showPassword = signal<boolean>(false);
  readonly loading = signal<boolean>(false);
  readonly error = signal<string>('');

  readonly returnUrl = signal<string>('/');

  constructor() {
    this.route.queryParamMap.pipe(takeUntilDestroyed()).subscribe((p) => {
      this.returnUrl.set(p.get('returnUrl') ?? '/');
    });
  }

  strengthLevel(): number {
    const p = this.password();
    let score = 0;
    if (p.length >= 6) score++;
    if (p.length >= 10) score++;
    if (/[A-Z]/.test(p) && /[a-z]/.test(p)) score++;
    if (/\d/.test(p) || /[!@#$%^&*]/.test(p)) score++;
    return score;
  }

  strengthLabel(): string {
    const s = this.strengthLevel();
    return ['อ่อนมาก', 'อ่อน', 'พอใช้', 'ดี', 'แข็งแรง'][s] ?? '';
  }

  strengthColor(): string {
    const s = this.strengthLevel();
    return [
      'text-rose-500',
      'text-rose-500',
      'text-amber-500',
      'text-emerald-500',
      'text-emerald-600',
    ][s] ?? '';
  }

  onSubmit(): void {
    this.error.set('');
    this.loading.set(true);
    setTimeout(() => {
      const r = this.auth.register({
        name: this.name(),
        email: this.email(),
        password: this.password(),
        confirmPassword: this.confirmPassword(),
        acceptTerms: this.acceptTerms(),
      });
      this.loading.set(false);
      if (!r.ok) {
        this.error.set(r.error ?? 'สมัครไม่สำเร็จ');
        return;
      }
      this.router.navigate(['/auth/verify-email'], {
        queryParams: { returnUrl: this.returnUrl() },
      });
    }, 600);
  }

  onSocial(provider: AuthProvider): void {
    this.loading.set(true);
    setTimeout(() => {
      this.auth.signInWithProvider(provider);
      this.loading.set(false);
      this.router.navigateByUrl(this.returnUrl());
    }, 500);
  }
}
