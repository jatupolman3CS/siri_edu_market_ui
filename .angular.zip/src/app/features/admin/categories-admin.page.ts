import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CatalogService } from '../../core/services';
import { IconComponent } from '../../shared/components/icon.component';
import { CompactPipe } from '../../shared/pipes/compact.pipe';

@Component({
  selector: 'app-admin-categories',
  standalone: true,
  imports: [IconComponent, CompactPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-5xl">
      <header class="flex items-center justify-between mb-8">
        <div>
          <h1 class="text-3xl font-extrabold text-ink mb-1">หมวดหมู่</h1>
          <p class="text-sm text-ink-soft">จัดการหมวดหมู่เอกสารบนแพลตฟอร์ม</p>
        </div>
        <button class="btn-pink">
          <app-icon name="plus" [size]="16" />
          เพิ่มหมวดหมู่
        </button>
      </header>

      <div class="card-soft overflow-hidden">
        <table class="w-full">
          <thead class="bg-pink-50">
            <tr class="text-left text-xs uppercase tracking-wider text-ink-muted">
              <th class="px-5 py-3 font-semibold">ชื่อหมวด</th>
              <th class="px-5 py-3 font-semibold">Slug</th>
              <th class="px-5 py-3 font-semibold">คำอธิบาย</th>
              <th class="px-5 py-3 font-semibold text-right">เอกสาร</th>
              <th class="px-5 py-3"></th>
            </tr>
          </thead>
          <tbody>
            @for (c of catalog.categories(); track c.id) {
              <tr class="border-t border-line hover:bg-pink-50/40">
                <td class="px-5 py-3">
                  <div class="flex items-center gap-3">
                    <span class="w-10 h-10 rounded-2xl bg-pink-50 text-2xl flex items-center justify-center">
                      {{ c.icon }}
                    </span>
                    <span class="text-sm font-bold text-ink">{{ c.name }}</span>
                  </div>
                </td>
                <td class="px-5 py-3 text-xs text-ink-muted font-mono">{{ c.slug }}</td>
                <td class="px-5 py-3 text-sm text-ink-soft line-clamp-1 max-w-md">{{ c.description }}</td>
                <td class="px-5 py-3 text-sm font-bold text-ink text-right whitespace-nowrap">
                  {{ c.documentCount | compact }}
                </td>
                <td class="px-5 py-3">
                  <div class="flex items-center gap-1 justify-end">
                    <button class="btn-icon !w-8 !h-8" title="แก้ไข">
                      <app-icon name="edit" [size]="14" />
                    </button>
                    <button class="btn-icon !w-8 !h-8 hover:!bg-rose-50 hover:!text-rose-500" title="ลบ">
                      <app-icon name="trash" [size]="14" />
                    </button>
                  </div>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  `,
})
export class AdminCategoriesPage {
  readonly catalog = inject(CatalogService);
}
