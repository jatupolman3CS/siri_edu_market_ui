import { ChangeDetectionStrategy, Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IconComponent } from '../../shared/components/icon.component';

@Component({
  selector: 'app-admin-settings',
  standalone: true,
  imports: [FormsModule, IconComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-3xl">
      <header class="mb-8">
        <h1 class="text-3xl font-extrabold text-ink mb-1">ตั้งค่าแพลตฟอร์ม</h1>
        <p class="text-sm text-ink-soft">การตั้งค่าหลักของระบบ — เปลี่ยนแปลงด้วยความระมัดระวัง</p>
      </header>

      <section class="card-soft p-6 mb-6">
        <h2 class="text-lg font-bold text-ink mb-1">ค่าธรรมเนียมและส่วนแบ่ง</h2>
        <p class="text-xs text-ink-muted mb-5">การคำนวณรายได้ของผู้ขาย</p>

        <div class="grid sm:grid-cols-2 gap-4">
          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">ค่าธรรมเนียมแพลตฟอร์ม (%)</label>
            <input class="input-soft" value="10" type="number" />
          </div>
          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">VAT (%)</label>
            <input class="input-soft" value="7" type="number" />
          </div>
          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">ขั้นต่ำการถอน (THB)</label>
            <input class="input-soft" value="500" type="number" />
          </div>
          <div>
            <label class="text-xs font-semibold text-ink-soft mb-2 block">รอบจ่ายเงิน</label>
            <select class="input-soft cursor-pointer">
              <option>ทุกวันที่ 15 ของเดือน</option>
              <option>ทุกสิ้นเดือน</option>
              <option>ทุกสัปดาห์ (พุธ)</option>
            </select>
          </div>
        </div>
      </section>

      <section class="card-soft p-6 mb-6">
        <h2 class="text-lg font-bold text-ink mb-1">การชำระเงิน</h2>
        <p class="text-xs text-ink-muted mb-5">ระบบ Payment Gateway ที่เชื่อมต่อ</p>
        <ul class="space-y-3">
          @for (g of gateways; track g.name) {
            <li class="flex items-center gap-4 p-4 rounded-2xl border border-line">
              <span class="text-2xl">{{ g.icon }}</span>
              <div class="flex-1">
                <div class="text-sm font-bold text-ink">{{ g.name }}</div>
                <div class="text-xs text-ink-muted">{{ g.note }}</div>
              </div>
              <span class="pill bg-emerald-100 text-emerald-700">เชื่อมต่อแล้ว</span>
            </li>
          }
        </ul>
      </section>

      <section class="card-soft p-6 mb-6">
        <h2 class="text-lg font-bold text-ink mb-1">การจัดเก็บไฟล์</h2>
        <p class="text-xs text-ink-muted mb-5">Cloudflare R2 — S3-Compatible Storage</p>

        <dl class="grid grid-cols-2 gap-4 p-5 rounded-3xl bg-pink-50">
          <div>
            <dt class="text-xs text-ink-muted">Bucket</dt>
            <dd class="text-sm font-bold text-ink mt-1 font-mono">siriedumarket-prod</dd>
          </div>
          <div>
            <dt class="text-xs text-ink-muted">Region</dt>
            <dd class="text-sm font-bold text-ink mt-1">APAC (auto)</dd>
          </div>
          <div>
            <dt class="text-xs text-ink-muted">ใช้พื้นที่</dt>
            <dd class="text-sm font-bold text-ink mt-1">4.2 GB</dd>
          </div>
          <div>
            <dt class="text-xs text-ink-muted">เอกสารทั้งหมด</dt>
            <dd class="text-sm font-bold text-ink mt-1">12,486 ไฟล์</dd>
          </div>
        </dl>
      </section>

      <div class="flex justify-end gap-3">
        <button class="btn-ghost">ยกเลิก</button>
        <button class="btn-pink">
          <app-icon name="check" [size]="16" />
          บันทึกการเปลี่ยนแปลง
        </button>
      </div>
    </div>
  `,
})
export class AdminSettingsPage {
  readonly gateways = [
    { name: 'Omise', icon: '💳', note: 'รับบัตรเครดิต Visa / Master / JCB' },
    { name: 'GB Prime Pay', icon: '🏦', note: 'PromptPay QR และ Internet Banking' },
    { name: 'TrueMoney Wallet', icon: '👛', note: 'หักจาก e-Wallet' },
  ];
}
