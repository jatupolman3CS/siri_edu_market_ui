import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { NzMessageService } from 'ng-zorro-antd/message';
import { CatalogService } from '../../core/services';
import { IconComponent } from '../../shared/components/icon.component';
import { EmptyStateComponent } from '../../shared/components/empty-state.component';
import { TimeAgoPipe } from '../../shared/pipes/time-ago.pipe';
import { ThbPipe } from '../../shared/pipes/thb.pipe';

@Component({
  selector: 'app-admin-approval',
  standalone: true,
  imports: [IconComponent, EmptyStateComponent, TimeAgoPipe, ThbPipe],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="max-w-7xl">
      <header class="mb-8">
        <h1 class="text-3xl font-extrabold text-ink mb-1">อนุมัติเอกสาร</h1>
        <p class="text-sm text-ink-soft">
          ตรวจสอบเอกสารที่ผู้ขายส่งเข้ามา ก่อนเผยแพร่บนตลาด
        </p>
      </header>

      <div class="grid lg:grid-cols-12 gap-6">
        <!-- List -->
        <div class="lg:col-span-5 space-y-3">
          <div class="text-sm text-ink-muted mb-2">
            <b class="text-ink">{{ catalog.pending().length }}</b> รายการรอตรวจสอบ
          </div>

          @if (catalog.pending().length === 0) {
            <app-empty-state emoji="🌿" title="ไม่มีเอกสารรออนุมัติ" description="ทุกอย่างเรียบร้อย!" />
          } @else {
            @for (d of catalog.pending(); track d.id) {
              <button
                class="w-full text-left card-soft p-4 flex items-start gap-3 hover:!border-pink-300 transition-all"
                [class.!border-pink-500]="selectedId() === d.id"
                [class.shadow-pop]="selectedId() === d.id"
                (click)="selectedId.set(d.id)"
              >
                <img [src]="d.cover" class="w-14 h-16 rounded-xl object-cover flex-shrink-0" alt="" />
                <div class="flex-1 min-w-0">
                  <div class="flex items-center gap-2 mb-1">
                    <span class="pill bg-amber-100 text-amber-700 !py-0 !text-[10px]">
                      <app-icon name="flag" [size]="10" />
                      รอตรวจสอบ
                    </span>
                    <span class="text-[11px] text-ink-muted">{{ d.createdAt | timeAgo }}</span>
                  </div>
                  <div class="text-sm font-bold text-ink line-clamp-2 leading-snug">
                    {{ d.title }}
                  </div>
                  <div class="text-xs text-ink-muted mt-1">{{ d.seller.studioName }}</div>
                </div>
              </button>
            }
          }
        </div>

        <!-- Preview -->
        <div class="lg:col-span-7">
          @if (selected(); as d) {
            <div class="card-soft overflow-hidden">
              <div class="relative aspect-[16/9] bg-pink-50 flex items-center justify-center">
                <img [src]="d.cover" class="w-full h-full object-cover" alt="" />
                <div class="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div class="text-white/40 text-7xl font-extrabold tracking-[0.3em] uppercase rotate-[-30deg] select-none">
                    review
                  </div>
                </div>
              </div>

              <div class="p-6">
                <div class="flex items-center gap-2 mb-3 flex-wrap">
                  @for (tag of d.tags; track tag) {
                    <span class="pill-soft">#{{ tag }}</span>
                  }
                </div>
                <h2 class="text-2xl font-extrabold text-ink leading-tight mb-2">{{ d.title }}</h2>
                <p class="text-sm text-ink-soft leading-relaxed">{{ d.shortDescription }}</p>

                <dl class="mt-5 grid sm:grid-cols-3 gap-4 p-5 rounded-3xl bg-pink-50 border border-line">
                  <div>
                    <dt class="text-xs text-ink-muted">ราคา</dt>
                    <dd class="text-base font-bold text-ink mt-1">{{ d.price | thb }}</dd>
                  </div>
                  <div>
                    <dt class="text-xs text-ink-muted">รูปแบบไฟล์</dt>
                    <dd class="text-base font-bold text-ink mt-1 uppercase">{{ d.format }} · {{ d.pages }} หน้า</dd>
                  </div>
                  <div>
                    <dt class="text-xs text-ink-muted">ผู้ขาย</dt>
                    <dd class="text-base font-bold text-ink mt-1">{{ d.seller.studioName }}</dd>
                  </div>
                </dl>

                <!-- Compliance check -->
                <h3 class="text-sm font-bold text-ink mt-6 mb-3">รายการตรวจสอบ</h3>
                <ul class="space-y-2">
                  @for (c of checks; track c.label) {
                    <li class="flex items-start gap-3 p-3 rounded-2xl border border-line">
                      <span
                        class="w-6 h-6 rounded-lg flex items-center justify-center flex-shrink-0"
                        [class]="c.ok ? 'bg-emerald-100 text-emerald-600' : 'bg-amber-100 text-amber-600'"
                      >
                        @if (c.ok) {
                          <app-icon name="check" [size]="14" />
                        } @else {
                          <app-icon name="flag" [size]="14" />
                        }
                      </span>
                      <div class="text-sm">
                        <div class="font-semibold text-ink">{{ c.label }}</div>
                        <div class="text-xs text-ink-muted mt-0.5">{{ c.note }}</div>
                      </div>
                    </li>
                  }
                </ul>

                <div class="grid sm:grid-cols-2 gap-3 mt-6">
                  <button
                    class="inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-full bg-rose-500 hover:bg-rose-600 text-white font-bold transition-colors"
                    (click)="reject(d.id, d.title)"
                  >
                    <app-icon name="x" [size]="16" />
                    ปฏิเสธพร้อมเหตุผล
                  </button>
                  <button
                    class="btn-pink !py-3.5"
                    (click)="approve(d.id, d.title)"
                  >
                    <app-icon name="check" [size]="16" />
                    อนุมัติเผยแพร่
                  </button>
                </div>
              </div>
            </div>
          } @else {
            <app-empty-state
              emoji="👈"
              title="เลือกเอกสารเพื่อตรวจสอบ"
              description="คลิกการ์ดด้านซ้ายเพื่อเริ่มตรวจสอบรายละเอียด"
            />
          }
        </div>
      </div>
    </div>
  `,
})
export class AdminApprovalPage {
  readonly catalog = inject(CatalogService);
  private readonly message = inject(NzMessageService);

  readonly selectedId = signal<string>('');

  readonly selected = computed(() => {
    const list = this.catalog.pending();
    if (!list.length) return null;
    const id = this.selectedId() || list[0].id;
    return list.find((d) => d.id === id) ?? list[0];
  });

  readonly checks = [
    { label: 'เอกสารตรงกับคำอธิบาย', note: 'AI ตรวจสอบความสอดคล้องของเนื้อหา', ok: true },
    { label: 'ไม่ละเมิดลิขสิทธิ์', note: 'ผ่านการตรวจ Plagiarism: 96% เป็นเนื้อหาต้นฉบับ', ok: true },
    { label: 'มีลายน้ำในไฟล์ตัวอย่าง', note: 'พบ Watermark Pattern ครบทุกหน้า', ok: true },
    { label: 'ภาพหน้าปกเหมาะสม', note: 'ภาพไม่มี nudity / violence', ok: true },
    { label: 'ราคาตรงกับเนื้อหา', note: 'อาจตรวจสอบเพิ่มเติม — เนื้อหาคุณภาพดี ราคาเฉลี่ยในหมวดสูงกว่านี้', ok: false },
  ];

  approve(id: string, title: string): void {
    this.catalog.approve(id);
    this.message.success(`อนุมัติ "${title}" เรียบร้อย`);
    this.selectedId.set('');
  }

  reject(id: string, title: string): void {
    this.catalog.reject(id);
    this.message.warning(`ปฏิเสธ "${title}" และแจ้งผู้ขายแล้ว`);
    this.selectedId.set('');
  }
}
