import { ChangeDetectionStrategy, Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { LogoComponent } from '../shared/components/logo.component';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink, LogoComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="min-h-screen flex flex-col items-center justify-center px-6 bg-canvas text-center">
      <app-logo />
      <div class="mt-12">
        <div class="text-[120px] md:text-[200px] font-extrabold text-pink-200 leading-none select-none">
          404
        </div>
        <h1 class="text-3xl font-extrabold text-ink -mt-8 mb-3">ไม่พบหน้าที่ต้องการ</h1>
        <p class="text-base text-ink-soft mb-8 max-w-md">
          หน้าเว็บที่คุณค้นหาอาจถูกย้าย ถูกลบ หรือไม่เคยมีอยู่จริง
          ลองกลับไปที่หน้าแรกหรือใช้ตัวค้นหากันใหม่
        </p>
        <div class="flex flex-wrap items-center justify-center gap-3">
          <a routerLink="/" class="btn-pink">กลับหน้าแรก</a>
          <a routerLink="/marketplace" class="btn-ghost">เลือกเอกสาร</a>
        </div>
      </div>
    </div>
  `,
})
export class NotFoundPage {}
